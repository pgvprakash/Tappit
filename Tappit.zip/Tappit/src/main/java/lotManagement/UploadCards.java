package lotManagement;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class UploadCards extends Tappit{
	
	// This is to confirm you are in Login Page
	public UploadCards(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public UploadCards acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public UploadCards enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public UploadCards enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public UploadCards selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public UploadCards clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public UploadCards clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Lot Management Menu
	public UploadCards clickLotManagement(){
		setExplicitWaitClickById(prop.getProperty("Lot.Menu.Id"));
		return this;
	}
	
	//This method is used to filter the program from the list
	public UploadCards selectProgram()throws Exception{
		selectVisibileTextByName(prop.getProperty("Lot.selectProgram.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the upload icon from the table
	public UploadCards clickUpload(){
		setExplicitWaitClickByXpath(prop.getProperty("Lot.UploadIcon.Xpath"));
		return this;
	}
	
	//This method is used to enter the card numbers in given field
	public UploadCards enterCards(){
		setExplicitWaitEnterByXpath(prop.getProperty("Lot.Cards.Xpath"), propDatas.getProperty("Lot.Upload.Cards"));
		return this;
	}
	
	//This method is used to click the upload button
	public UploadCards clickUploadButton()throws Exception {
		setExplicitWaitClickByXpath(prop.getProperty("Lot.Upload.Xpath"));
		Thread.sleep(3000);
		return this;
	}
}
