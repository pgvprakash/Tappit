package lotManagement;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class EditLotManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditLotManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditLotManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditLotManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditLotManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditLotManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditLotManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public EditLotManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Lot Management Menu
	public EditLotManagementPage clickLotManagement(){
		setExplicitWaitClickById(prop.getProperty("Lot.Menu.Id"));
		return this;
	}
	
	//This method is used to filter the program from the list
	public EditLotManagementPage selectProgram(){
		selectVisibileTextByName(prop.getProperty("Lot.selectProgram.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	//This method is used to click the edit icon from the table
	public EditLotManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Lot.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to modify the name in Lot Name field
	public EditLotManagementPage editName(){
		setExplicitWaitEnterByXpath(prop.getProperty("Lot.EditName.Xpath"), propDatas.getProperty("LotMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to modify the total cards field
	public EditLotManagementPage editTotalCards(){
		setExplicitWaitEnterByXpath(prop.getProperty("Lot.EditTotalCards.Xpath"), propDatas.getProperty("LotMgnt.Edit.TotalCards"));
		return this;
	}
	
	//This method is used to modify the Minimum Spend Limit
	public EditLotManagementPage editMinSpendLimit(){
		setExplicitWaitEnterByXpath(prop.getProperty("Lot.EditMinSpendLimit.Xpath"), propDatas.getProperty("LotMgnt.Edit.MinSpendLimit"));
		return this;
	}
	
	//This method is used to click the Submit button
	public EditLotManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Lot.SaveChanges.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the created Lot is displayed in table or not
	public EditLotManagementPage verifyUpdatedLot(){
		String actualLotName=getTextByXpath(prop.getProperty("Lot.VerifyLot.Xpath"));
		String expectedLotName=propDatas.getProperty("LotMgnt.Edit.Name");
		assertVerification(actualLotName, expectedLotName);
		return this;
	}
}
