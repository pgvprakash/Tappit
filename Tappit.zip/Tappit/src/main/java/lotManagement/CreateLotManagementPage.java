package lotManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateLotManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateLotManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateLotManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateLotManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateLotManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateLotManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateLotManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateLotManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Lot Management Menu
	public CreateLotManagementPage clickLotManagement(){
		setExplicitWaitClickById(prop.getProperty("Lot.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Add Lot in Lot management
	public CreateLotManagementPage clickAddLot(){
		setExplicitWaitClickByLink(prop.getProperty("Lot.AddLot.LinkText"));
		return this;
	}
	
	//This method is used to enter the name in the given field
	public CreateLotManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Lot.Name.Name"), propDatas.getProperty("LotMgnt.Create.Name"));
		return this;
	}
	
	//This method is used to select the expiration date of the lot
	public CreateLotManagementPage selectExpirationDate(){
		setExplicitWaitClickByName(prop.getProperty("Lot.ExpirationDate.Name"));
		setExplicitWaitClickByXpath(prop.getProperty("Lot.ExpDateSelection.Xpath"));
		return this;
	}
	
	//This method is used to enter the total cards required in this lot
	public CreateLotManagementPage enterTotalCards(){
		setExplicitWaitEnterByName(prop.getProperty("Lot.TotalCards.Name"), propDatas.getProperty("LotMgnt.Create.TotalCards"));
		return this;
	}
	
	//This method is used to select the device type from the list
	public CreateLotManagementPage selectDeviceType(){
		selectVisibileTextByName(prop.getProperty("Lot.DeviceType.Name"), propDatas.getProperty("LotMgnt.Create.DeviceType"));
		return this;
	}
	
	//This method is used to select the program from the list
	public CreateLotManagementPage selectProgram(){
		selectVisibileTextByName(prop.getProperty("Lot.Program.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to select the outlet name from the list
	public CreateLotManagementPage selectOutlet(){
		selectVisibileTextByName(prop.getProperty("Lot.Outlet.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to select the Flag from the list
	public CreateLotManagementPage selectFlag(){
		selectVisibileTextByName(prop.getProperty("Lot.Flag.Name"), propDatas.getProperty("LotMgnt.Create.Flag"));
		return this;
	}
	
	//This method is used to enter the load credit amount in given field
	public CreateLotManagementPage enterLoadCredit(){
		setExplicitWaitEnterByName(prop.getProperty("Lot.LoadCredit.Name"), propDatas.getProperty("LotMgnt.Create.SessionLoadCredit"));
		return this;
	}
	
	//This method is used to select the currency from the list
	public CreateLotManagementPage selectCurrency(){
		selectVisibileTextByXPath(prop.getProperty("Lot.LoadCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to enter the reset load credit in given field
	public CreateLotManagementPage enterResetLoadCredit(){
		setExplicitWaitEnterByName(prop.getProperty("Lot.ResetLoadCredit.Name"), propDatas.getProperty("LotMgnt.Create.ResetLoadCredit"));
		return this;
	}
	
	//This method is used to select the currency from the list
	public CreateLotManagementPage selectRestLoadCurrency(){
		selectVisibileTextByXPath(prop.getProperty("Lot.ResetLoadCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to enter the minimum spend limit in given field
	public CreateLotManagementPage enterMinimumSpendLimit(){
		setExplicitWaitEnterByName(prop.getProperty("Lot.MinSpendLimit.Name"), propDatas.getProperty("LotMgnt.Create.MinSpendLimit"));
		return this;
	}
	
	//This method is used to click the Add Access Data 
	public CreateLotManagementPage clickAddAccessData(){
		setExplicitWaitClickByXpath(prop.getProperty("Lot.AccessData.Xpath"));
		return this;
	}
	
	//This method is used to select the event from the list
	public CreateLotManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("Lot.Event.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to select the access flag from the list
	public CreateLotManagementPage selectAccessFlag()throws Exception {
		selectVisibileTextByName(prop.getProperty("Lot.AccessFlag.Name"), propDatas.getProperty("accessFlag.Edit.Name"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateLotManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Lot.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to filter the program from the list
	public CreateLotManagementPage filterProgram(){
		selectVisibileTextByName(prop.getProperty("Lot.selectProgram.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to verify the created Lot is displayed in table or not
	public CreateLotManagementPage verifyCreatedLot(){
		String actualLotName=getTextByXpath(prop.getProperty("Lot.VerifyLot.Xpath"));
		String expectedLotName=propDatas.getProperty("LotMgnt.Create.Name");
		assertVerification(actualLotName, expectedLotName);
		return this;
	}
}