package terminalManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class FleetSetup extends Tappit{
	
	// This is to confirm you are in Login Page
	public FleetSetup(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public FleetSetup acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public FleetSetup enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public FleetSetup enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public FleetSetup selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public FleetSetup clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public FleetSetup clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Terminal menu
	public FleetSetup clickTerminal(){
		setExplicitWaitClickById(prop.getProperty("Terminal.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Terminal Management menu
	public FleetSetup clickTerminalManagement(){
		setExplicitWaitClickById(prop.getProperty("Terminal.TerminalMgntMenu.Id"));
		return this;
	}
	
	//This method is used to click the add new terminal in terminal management
	public FleetSetup clickAddTerminal(){
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.AddTerminal.Xpath"));
		return this;
	}
	
	//This method is used to enter the terminal id in given field
	public FleetSetup enterTerminalId(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalId.Name"), propDatas.getProperty("Fleet.Create.TerminalId"));
		return this;
	}
	
	//This method is used to enter the terminal owner in the given field
	public FleetSetup enterTerminalOwner(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalOwner.Name"), propDatas.getProperty("Fleet.Create.TerminalOwner"));
		return this;
	}
	
	//This method is used to enter the terminal name in the given field
	public FleetSetup enterTerminalName(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalName.Name"), propDatas.getProperty("Fleet.Create.TerminalName"));
		return this;
	}
	
	//This method is used to select the terminal type from the list
	public FleetSetup selectTerminalType(){
		selectVisibileTextByName(prop.getProperty("Terminal.TerminalType.Name"), propDatas.getProperty("Fleet.Create.TerminalType"));
		return this;
	}
	
	//This method is used to select the outlet name from the list
	public FleetSetup selectOutlet(){
		selectVisibileTextByName(prop.getProperty("Terminal.Outlet.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to click the Submit button
	public FleetSetup clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to search the newly created terminal 
	public FleetSetup searchTerminalName(){
		setExplicitWaitEnterByXpath(prop.getProperty("Terminal.SearchTerminal.Xpath"), propDatas.getProperty("Fleet.Create.TerminalName"));
		return this;
	}
	
	//This method is used to click the Filter button
	public FleetSetup clickFilter(){
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.FilterButton.Xpath"));
		return this;
	}
	
	//This method is used to verify the terminal
	public FleetSetup verifyTerminal(){
		String actualTerminalName=getTextByXpath(prop.getProperty("Terminal.ActualTerminalName.Xpath"));
		String expectedTerminalName=propDatas.getProperty("Fleet.Create.TerminalName");
		assertVerification(actualTerminalName, expectedTerminalName);
		return this;
	}
	
	
	


}
