package terminalManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateTerminalManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateTerminalManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateTerminalManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateTerminalManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateTerminalManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateTerminalManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateTerminalManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateTerminalManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Terminal menu
	public CreateTerminalManagementPage clickTerminal(){
		setExplicitWaitClickById(prop.getProperty("Terminal.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Terminal Management menu
	public CreateTerminalManagementPage clickTerminalManagement(){
		setExplicitWaitClickById(prop.getProperty("Terminal.TerminalMgntMenu.Id"));
		return this;
	}
	
	//This method is used to click the add new terminal in terminal management
	public CreateTerminalManagementPage clickAddTerminal(){
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.AddTerminal.Xpath"));
		return this;
	}
	
	//This method is used to enter the terminal id in given field
	public CreateTerminalManagementPage enterTerminalId(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalId.Name"), propDatas.getProperty("Terminal.Create.TerminalId"));
		return this;
	}
	
	//This method is used to enter the terminal owner in the given field
	public CreateTerminalManagementPage enterTerminalOwner(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalOwner.Name"), propDatas.getProperty("Terminal.Create.TerminalOwner"));
		return this;
	}
	
	//This method is used to enter the terminal name in the given field
	public CreateTerminalManagementPage enterTerminalName(){
		setExplicitWaitEnterByName(prop.getProperty("Terminal.TerminalName.Name"), propDatas.getProperty("Terminal.Create.TerminalName"));
		return this;
	}
	
	//This method is used to select the terminal type from the list
	public CreateTerminalManagementPage selectTerminalType(){
		selectVisibileTextByName(prop.getProperty("Terminal.TerminalType.Name"), propDatas.getProperty("Terminal.Create.TerminalType"));
		return this;
	}
	
	//This method is used to select the outlet name from the list
	public CreateTerminalManagementPage selectOutlet(){
		selectVisibileTextByName(prop.getProperty("Terminal.Outlet.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateTerminalManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to search the newly created terminal 
	public CreateTerminalManagementPage searchTerminalName(){
		setExplicitWaitEnterByXpath(prop.getProperty("Terminal.SearchTerminal.Xpath"), propDatas.getProperty("Terminal.Create.TerminalName"));
		return this;
	}
	
	//This method is used to click the Filter button
	public CreateTerminalManagementPage clickFilter(){
		setExplicitWaitClickByXpath(prop.getProperty("Terminal.FilterButton.Xpath"));
		return this;
	}
	
	//This method is used to verify the terminal
	public CreateTerminalManagementPage verifyTerminal(){
		String actualTerminalName=getTextByXpath(prop.getProperty("Terminal.ActualTerminalName.Xpath"));
		String expectedTerminalName=propDatas.getProperty("Terminal.Create.TerminalName");
		assertVerification(actualTerminalName, expectedTerminalName);
		return this;
	}
}
