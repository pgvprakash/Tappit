package deviceProfileManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateDeviceProfileManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateDeviceProfileManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateDeviceProfileManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateDeviceProfileManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateDeviceProfileManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateDeviceProfileManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateDeviceProfileManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateDeviceProfileManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Device Profile Management from sub menu
	public CreateDeviceProfileManagementPage clickDeviceProfileManagement(){
		setExplicitWaitClickById(prop.getProperty("Device.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Add Profile link
	public CreateDeviceProfileManagementPage clickAddDeviceProfile(){
		setExplicitWaitClickByLink(prop.getProperty("Device.AddProfile.LinkText"));
		return this;
	}
	
	//This method is used to enter the device profile name in the given field
	public CreateDeviceProfileManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Device.ProfileName.Name"), propDatas.getProperty("Device.Create.Name"));
		return this;
	}
	
	//This method is used to select the event name from the list
	public CreateDeviceProfileManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("Device.SelectEvent.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to click the POS check box
	public CreateDeviceProfileManagementPage clickPOS()throws Exception{
		Thread.sleep(3000);
		setExplicitWaitClickByXpath(prop.getProperty("Device.POSCheckBox.Xpath"));
		return this;
	}
	
	//This method is used to click the Load check box
	public CreateDeviceProfileManagementPage clickLoad(){
		setExplicitWaitClickByXpath(prop.getProperty("Device.LoadCheckBox.Xpath"));
		return this;
	}
	
	//This method is used to click the Access Check box
	public CreateDeviceProfileManagementPage clickAccess(){
		setExplicitWaitClickByXpath(prop.getProperty("Device.AccessCheckBox.Xpath"));
		return this;
	}
	
	//This method is used to select the invoice enable/disable from the list
	public CreateDeviceProfileManagementPage selectInvoice(){
		selectVisibileTextByXPath(prop.getProperty("Device.Invoice.Xpath"), propDatas.getProperty("Device.Create.Invoice"));
		return this;
	}
	
	//This method is used to select the admin device enable/disable from the list
	public CreateDeviceProfileManagementPage selectAdminDevice(){
		selectVisibileTextByXPath(prop.getProperty("Device.AdminDevice.Xpath"), propDatas.getProperty("Device.Create.AdminDevice"));
		return this;
	}
	
	//This method is used to select the QR Load enable/disable from the list
	public CreateDeviceProfileManagementPage selectQRLoad(){
		selectVisibileTextByXPath(prop.getProperty("Device.QRLoad.Xpath"), propDatas.getProperty("Device.Create.QRLoad"));
		return this;
	}
	
	//This method is used to select the GPS enable/disable from the list
	public CreateDeviceProfileManagementPage selectGPS(){
		selectVisibileTextByXPath(prop.getProperty("Device.GPS.Xpath"), propDatas.getProperty("Device.Create.GPS"));
		return this;
	}
	
	//This method is used to select the Reset Agent Cash enable/disable from the list
	public CreateDeviceProfileManagementPage selectResetAgentCash(){
		selectVisibileTextByXPath(prop.getProperty("Device.ResetAgentCash.Xpath"), propDatas.getProperty("Device.Create.ResetAgentCash"));
		return this;
	}
	
	//This method is used to select the Drawer enable/disable from the list
	public CreateDeviceProfileManagementPage selectDrawer(){
		selectVisibileTextByXPath(prop.getProperty("Device.Drawer.Xpath"), propDatas.getProperty("Device.Create.Drawer"));
		return this;
	}
	
	//This method is used to select the device type enable/disable from the list
	public CreateDeviceProfileManagementPage selectDeviceType(){
		selectVisibileTextByXPath(prop.getProperty("Device.DeviceType.Xpath"), propDatas.getProperty("Device.Create.DeviceType"));
		return this;
	}
	
	//This method is used to select the Fees enable/disable from the list
	public CreateDeviceProfileManagementPage selectFees(){
		selectVisibileTextByXPath(prop.getProperty("Device.Fees.Xpath"), propDatas.getProperty("Device.Create.Fees"));
		return this;
	}
	
	//This method is used to select the Log Upload EOD enable/disable from the list
	public CreateDeviceProfileManagementPage selectLogUploadEOD(){
		selectVisibileTextByXPath(prop.getProperty("Device.LogUploadEOD.Xpath"), propDatas.getProperty("Device.Create.LogOnUpload"));
		return this;
	}
	
	//This method is used to enter the manager pin in the given field
	public CreateDeviceProfileManagementPage enterManagerPin(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.ManagerPin.Xpath"), propDatas.getProperty("Device.Create.ManagerPin"));
		return this;
	}
	
	//This method is used to enter the Admin pin in the given field
	public CreateDeviceProfileManagementPage enterAdminPin(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.AdminPin.Xpath"), propDatas.getProperty("Device.Create.AdminPin"));
		return this;
	}
	
	//This method is used to select the Double Tap enable/disable from the list
	public CreateDeviceProfileManagementPage selectDoubleTap(){
		selectVisibileTextByXPath(prop.getProperty("Device.DoubleTap.Xpath"), propDatas.getProperty("Device.Create.DoubleTap"));
		return this;
	}
	
	//This method is used to select the Open Reconcile Drawer enable/disable from the list
	public CreateDeviceProfileManagementPage selectReconcileDrawer(){
		selectVisibileTextByXPath(prop.getProperty("Device.ReconcileDrawer.Xpath"), propDatas.getProperty("Device.Create.ReconcileDrawer"));
		return this;
	}
	
	//This method is used to select the POS Auto Invoice enable/disable from the list
	public CreateDeviceProfileManagementPage selectPOSAutoInvoice(){
		selectVisibileTextByXPath(prop.getProperty("Device.POSAutoInvoice.Xpath"), propDatas.getProperty("Device.Create.POSAutoInvoice"));
		return this;
	}
	
	//This method is used to select the Online Preload enable/disable from the list
	public CreateDeviceProfileManagementPage selectOnlinePreload(){
		selectVisibileTextByXPath(prop.getProperty("Device.OnlinePreload.Xpath"), propDatas.getProperty("Device.Create.OnlinePreload"));
		return this;
	}
	
	//This method is used to select the Session Initialization enable/disable from the list
	public CreateDeviceProfileManagementPage selectSessionInitialization(){
		selectVisibileTextByXPath(prop.getProperty("Device.SessionInitialization.Xpath"), propDatas.getProperty("Device.Create.SessionInitialization"));
		return this;
	}
	
	//This method is used to enter the reconcile pin in the given field
	public CreateDeviceProfileManagementPage enterReconcilePin(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.ReconcilePin.Xpath"), propDatas.getProperty("Device.Create.ReconcilePin"));
		return this;
	}
	
	//This method is used to enter the Sale Amount limit in the given field
	public CreateDeviceProfileManagementPage enterSaleAmountLimit(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.SaleAmountLimit.Xpath"), propDatas.getProperty("Device.Create.SaleAmountLimit"));
		return this;
	}
	
	//This method is used to select the language from the list
	public CreateDeviceProfileManagementPage selectLanguage(){
		selectVisibileTextByXPath(prop.getProperty("Device.Language.Xpath"), propDatas.getProperty("Device.Create.Language"));
		return this;
	}
	
	//This method is used to enter the url in given filed
	public CreateDeviceProfileManagementPage enterUrl(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.URL.Xpath"), propDatas.getProperty("Device.Create.Url"));
		return this;
	}
	
	//This method is used to enter the App Lock pin in given field
	public CreateDeviceProfileManagementPage enterAppLockPin(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.AppLockPin.Xpath"), propDatas.getProperty("Device.Create.AppLockPin"));
		return this;
	}
	
	//This method is used to select the Mode from the list
	public CreateDeviceProfileManagementPage selectMode(){
		selectVisibileTextByXPath(prop.getProperty("Device.Mode.Xpath"), propDatas.getProperty("Device.Create.Mode"));
		return this;
	}
	
	//This method is used to enter the Sale time limit in the given field
	public CreateDeviceProfileManagementPage enterSaleTimeLimit(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.SaleTimeLimit.Xpath"), propDatas.getProperty("Device.Create.SaleTimeLimit"));
		return this;
	}
	
	//This method is used to select the Balance from the list
	public CreateDeviceProfileManagementPage selectBalance(){
		selectVisibileTextByXPath(prop.getProperty("Device.Balance.Xpath"), propDatas.getProperty("Device.Create.Balance"));
		return this;
	}
	
	//This method is used to enter the POS tips denomination in the given field
	public CreateDeviceProfileManagementPage enterPOSTipsDenom(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.TipsDenomination.Xpath"), propDatas.getProperty("Device.Create.TipsDenomination"));
		return this;
	}
	
	//This method is used to select the Menu from the list
	public CreateDeviceProfileManagementPage selectMenu(){
		selectVisibileTextByXPath(prop.getProperty("Device.SelectMenu.Xpath"), propDatas.getProperty("Device.Create.Menu"));
		return this;
	}
	
	//This method is used to enter the refund interval in given field
	public CreateDeviceProfileManagementPage enterRefundInterval(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.RefundInterval.Xpath"), propDatas.getProperty("Device.Create.RefundInterval"));
		return this;
	}
	
	//This method is used to select the Cashout from the list
	public CreateDeviceProfileManagementPage selectCashout(){
		selectVisibileTextByXPath(prop.getProperty("Device.Cashout.Xpath"), propDatas.getProperty("Device.Create.Cashout"));
		return this;
	}
	
	//This method is used to enter the Denom3 in given field
	public CreateDeviceProfileManagementPage enterDenom3(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.Denom3.Xpath"), propDatas.getProperty("Device.Create.Denom3"));
		return this;
	}
	
	//This method is used to enter the Denom2 in given field
	public CreateDeviceProfileManagementPage enterDenom2(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.Denom2.Xpath"), propDatas.getProperty("Device.Create.Denom2"));
		return this;
	}
	
	//This method is used to enter the Denom1 in given field
	public CreateDeviceProfileManagementPage enterDenom1(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.Denom1.Xpath"), propDatas.getProperty("Device.Create.Denom1"));
		return this;
	}
	
	//This method is used to enable the ticket Register from the list
	public CreateDeviceProfileManagementPage enableTicketRegister(){
		selectVisibileTextByXPath(prop.getProperty("Device.TicketRegister.Xpath"), propDatas.getProperty("Device.Create.TicketRegister"));
		return this;
	}
	
	//This method is used to enter the Denom4 in given field
	public CreateDeviceProfileManagementPage enterDenom4(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.Denom4.Xpath"), propDatas.getProperty("Device.Create.Denom4"));
		return this;
	}
	
	//This method is used to enable the multiRegister from the list
	public CreateDeviceProfileManagementPage enableMultiRegister(){
		selectVisibileTextByXPath(prop.getProperty("Device.MultiRegister.Xpath"), propDatas.getProperty("Device.Create.MultiRegister"));
		return this;
	}
	
	//This method is used to selct the Source Mode from the list
	public CreateDeviceProfileManagementPage selectSourceMode(){
		selectVisibileTextByXPath(prop.getProperty("Device.SourceMode.Xpath"), propDatas.getProperty("Device.Create.SourceMode"));
		return this;
	}
	
	//This method is used to select the Load Currency from the list
	public CreateDeviceProfileManagementPage selectLoadCurrency()throws Exception{
		Thread.sleep(3000);
		selectVisibileTextByXPath(prop.getProperty("Device.LoadCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to select the unload currency from the list
	public CreateDeviceProfileManagementPage selectUnloadCurrency()throws Exception{
		Thread.sleep(3000);
		selectVisibileTextByXPath(prop.getProperty("Device.UnloadCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to enable the Guest Register from the list
	public CreateDeviceProfileManagementPage enableGuestRegister(){
		selectVisibileTextByXPath(prop.getProperty("Device.GuestRegister.Xpath"), propDatas.getProperty("Device.Create.GuestRegister"));
		return this;
	}
	
	//This method is used to enable the allow unknown ticket
	public CreateDeviceProfileManagementPage enableAllowUnknownTicket(){
		selectVisibileTextByXPath(prop.getProperty("Device.AllowUnknownTicket.Xpath"), propDatas.getProperty("Device.Create.AllowUnknownTicket"));
		return this;
	}
	
	//This method is used to choose the Register Mode from the list
	public CreateDeviceProfileManagementPage selectRegisterMode(){
		selectVisibileTextByXPath(prop.getProperty("Device.RegisterMode.Xpath"), propDatas.getProperty("Device.Create.RegisterMode"));
		return this;
	}
	
	//This method is used to enable the Customer register from the list
	public CreateDeviceProfileManagementPage enableCustomerRegister(){
		selectVisibileTextByXPath(prop.getProperty("Device.CustomerRegister.Xpath"), propDatas.getProperty("Device.Create.CustomerRegister"));
		return this;
	}
	
	//This method is used to select the Gate from the list
	public CreateDeviceProfileManagementPage selectGate(){
		selectVisibileTextByXPath(prop.getProperty("Device.Gate.Xpath"), propDatas.getProperty("gate.Edit.GateName"));
		return this;
	}
	
	//This method is used to enter the disabled area in the given field
	public CreateDeviceProfileManagementPage enterDisabledArea(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.DisabledArea.Xpath"), propDatas.getProperty("Device.Create.DisabledArea"));
		return this;
	}
	
	//This method is used to enter the access profile in the given field
	public CreateDeviceProfileManagementPage enterAccessProfile(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.Profile.Xpath"), propDatas.getProperty("Device.Create.Profile"));
		return this;
	}
	
	//This method is used to enable the Previous location override
	public CreateDeviceProfileManagementPage enablePrevLocation(){
		selectVisibileTextByXPath(prop.getProperty("Device.PrevLocationOverride.Xpath"), propDatas.getProperty("Device.Create.PrevLocationOverride"));
		return this;
	}
	
	//This method is used to enter the time interval in given field
	public CreateDeviceProfileManagementPage enterTimeInterval(){
		setExplicitWaitEnterByXpath(prop.getProperty("Device.TimerInterval.Xpath"), propDatas.getProperty("Device.Create.TimerInterval"));
		return this;
	}
	
	//This method is used to enable the Prev location prompt
	public CreateDeviceProfileManagementPage enablePrevLocationPrompt()throws Exception{
		selectVisibileTextByXPath(prop.getProperty("Device.PrevLocationOverridePrompt.Xpath"), propDatas.getProperty("Device.Create.PrevLocationOverridePrompt"));
		Thread.sleep(5000);
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateDeviceProfileManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Device.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
}
