package deviceProfileManagement;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class AutoGenerateProfilePage extends Tappit{
	
	// This is to confirm you are in Login Page
	public AutoGenerateProfilePage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public AutoGenerateProfilePage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public AutoGenerateProfilePage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public AutoGenerateProfilePage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public AutoGenerateProfilePage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public AutoGenerateProfilePage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public AutoGenerateProfilePage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Device Profile Management from sub menu
	public AutoGenerateProfilePage clickDeviceProfileManagement(){
		setExplicitWaitClickById(prop.getProperty("Device.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Auto Generate Profile button
	public AutoGenerateProfilePage clickAutoGenerateProfile(){
		setExplicitWaitClickByXpath(prop.getProperty("Auto.AutoGenerateProfile.Xpath"));
		return this;
	}
	
	//This method is used to click the Generate button
	public AutoGenerateProfilePage ClickGenerateButton(){
		setExplicitWaitClickByXpath(prop.getProperty("Auto.Generate.Xpath"));
		return this;
	}
	
	//This method is used to click the Save Changes button 
	public AutoGenerateProfilePage ClickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Auto.SaveChanges.Xpath"));
		Thread.sleep(3000);
		return this;
	}
}