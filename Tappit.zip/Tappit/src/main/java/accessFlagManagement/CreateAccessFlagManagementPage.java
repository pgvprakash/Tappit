package accessFlagManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateAccessFlagManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateAccessFlagManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateAccessFlagManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateAccessFlagManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateAccessFlagManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateAccessFlagManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateAccessFlagManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateAccessFlagManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Access Flag Management Menu
	public CreateAccessFlagManagementPage clickAccessFlagManagement(){
		setExplicitWaitClickById(prop.getProperty("AccessFlag.AccessFlagMenu.Id"));
		return this;
	}
	
	//This method is used to click the Add Access Flag in Access Flag management
	public CreateAccessFlagManagementPage clickAddAccessFlag(){
		setExplicitWaitClickByLink(prop.getProperty("AccessFlag.AddAccessFlag.LinkText"));
		return this;
	}
	
	//This method is used to select the event from the list
	public CreateAccessFlagManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("AccessFlag.SelectEvent.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to select the program from the list
	public CreateAccessFlagManagementPage selectProgram(){
		selectVisibileTextByName(prop.getProperty("AccessFlag.SelectProgram.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to enter the access flag name in the given field
	public CreateAccessFlagManagementPage enterAccessFlagName(){
		setExplicitWaitEnterByName(prop.getProperty("AccessFlag.FlagName.Name"), propDatas.getProperty("accessFlag.Create.Name"));
		return this;
	}
	
	//This method is used to enter the access in area
	public CreateAccessFlagManagementPage enterAreaAccess(){
		setExplicitWaitEnterByXpath(prop.getProperty("AccessFlag.AreaAccess.Xpath"), propDatas.getProperty("accessFlag.Create.AreaAccess"));
		return this;
	}
	
	//This method is used to select the write type from the list
	public CreateAccessFlagManagementPage selectWriteType(){
		selectVisibileTextByXPath(prop.getProperty("AccessFlag.WriteType.Xpath"), propDatas.getProperty("accessFlag.Create.WriteType"));
		return this;
	}
	
	//This method is used to click the submit button
	public CreateAccessFlagManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.Submit.Xpath"));
		Thread.sleep(6000);
		return this;
	}	
	
	//This method is used to click the select name field
	public CreateAccessFlagManagementPage clickSelectName(){
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.selectName.Xpath"));
		return this;
	}
	
	//This method is used to enter the name in the given field
	public CreateAccessFlagManagementPage enterFlagName(){
		setExplicitWaitEnterByXpath(prop.getProperty("AccessFlag.EnterSearch.Xpath"), propDatas.getProperty("accessFlag.Create.Name"));
		return this;
	}
	
	//This method is used to select the flag from the list
	public CreateAccessFlagManagementPage clickFlagName(){
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.FlagName.Xpath"));
		return this;
	}
	
	//This method is used to click the Filter button
	public CreateAccessFlagManagementPage clickFilter()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.Filter.Xpath"));
		Thread.sleep(2000);
		return this;
	}
	
	//This method is used to verify the newly created flag in access flag management
	public CreateAccessFlagManagementPage verifyAccessFlagName(){
		String actualProgramName=getTextByXpath(prop.getProperty("AccessFlag.VerifyFlagName.Xpath"));
		String expectedProgramName=propDatas.getProperty("accessFlag.Create.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}
