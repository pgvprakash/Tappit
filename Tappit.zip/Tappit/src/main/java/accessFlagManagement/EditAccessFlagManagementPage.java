package accessFlagManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditAccessFlagManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditAccessFlagManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditAccessFlagManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditAccessFlagManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditAccessFlagManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditAccessFlagManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditAccessFlagManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditAccessFlagManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Access Flag Management Menu
	public EditAccessFlagManagementPage clickAccessFlagManagement(){
		setExplicitWaitClickById(prop.getProperty("AccessFlag.AccessFlagMenu.Id"));
		return this;
	}
	
	//This method is used to click the edit icon from the grid/table
	public EditAccessFlagManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to modify the existing access flag name
	public EditAccessFlagManagementPage editAccessFlagName(){
		setExplicitWaitEnterByXpath(prop.getProperty("AccessFlag.EditName.Xpath"), propDatas.getProperty("accessFlag.Edit.Name"));
		return this;
	}
	
	//This method is used to click the save changes button
	public EditAccessFlagManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.SaveChanges.Xpath"));
		Thread.sleep(6000);
		return this;
	}
	
	//This method is used to click the select name field
	public EditAccessFlagManagementPage clickSelectName(){
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.selectName.Xpath"));
		return this;
	}
	
	//This method is used to enter the name in the given field
	public EditAccessFlagManagementPage enterFlagName(){
		setExplicitWaitEnterByXpath(prop.getProperty("AccessFlag.EnterSearch.Xpath"), propDatas.getProperty("accessFlag.Create.Name"));
		return this;
	}
	
	//This method is used to select the flag from the list
	public EditAccessFlagManagementPage clickFlagName(){
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.FlagName.Xpath"));
		return this;
	}
	
	//This method is used to click the Filter button
	public EditAccessFlagManagementPage clickFilter()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("AccessFlag.Filter.Xpath"));
		Thread.sleep(2000);
		return this;
	}
	
	//This method is used to verify the newly created flag in access flag management
	public EditAccessFlagManagementPage verifyAccessFlagName(){
		String actualProgramName=getTextByXpath(prop.getProperty("AccessFlag.VerifyFlagName.Xpath"));
		String expectedProgramName=propDatas.getProperty("accessFlag.Edit.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}