package eventManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditSessionManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditSessionManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditSessionManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditSessionManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditSessionManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditSessionManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditSessionManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditSessionManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Event Management sub menu
	public EditSessionManagementPage clickEventManagement(){
		setExplicitWaitClickById(prop.getProperty("EventMgnt.EventMgnt.Id"));
		return this;
	}

	//This  method is used to click the edit icon from the existing event
	public EditSessionManagementPage clickSessionIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Session.SessionIcon.Xpath"));
		return this;
	}
	
	//This method is used to edit the existing session in event
	public EditSessionManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Session.EditIcon.Xpath"));
		return this;
	}
	//This method is used to modify the start date of an session
	public EditSessionManagementPage enterStartTime(){
		setExplicitWaitEnterByXpath(prop.getProperty("Session.StartTime.Xpath"), propDatas.getProperty("eventMgnt.Edit.StartDate"));
		return this;
	}
	
	//This method is used to modify the end date of an session
	public EditSessionManagementPage enterEndTime(){
		setExplicitWaitEnterByXpath(prop.getProperty("Session.EndTime.Xpath"), propDatas.getProperty("session.Edit.EndTime"));
		return this;
	}
	
	//This method used to modify the reset balance
	public EditSessionManagementPage selectResetBalance(){
		selectByValueXpath(prop.getProperty("Session.ResetBalance.Xpath"), propDatas.getProperty("Session.ResetLoadCredit.Xpath"));
		return this;
	}
	
	//This method is used to modify the Reset Load Credit
	public EditSessionManagementPage selectResetLoadCredit(){
		selectByValueXpath(prop.getProperty("Session.ResetLoadCredit.Xpath"), propDatas.getProperty("session.Edit.ResetLoadCredit"));
		return this;
	}
	
	//This method is used to click the Save Changes button from edit session page
	public EditSessionManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Session.SaveChanges.Xpath"));
		Thread.sleep(5000);
		return this;
	}
}
