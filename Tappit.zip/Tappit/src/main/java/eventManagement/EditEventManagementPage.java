package eventManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class EditEventManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public EditEventManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditEventManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditEventManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditEventManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditEventManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditEventManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditEventManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Event Management sub menu
	public EditEventManagementPage clickEventManagement(){
		setExplicitWaitClickById(prop.getProperty("EventMgnt.EventMgnt.Id"));
		return this;
	}

	//This  method is used to click the edit icon from the existing event
	public EditEventManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to modify the event name in existing event
	public EditEventManagementPage enterEventName(){
		setExplicitWaitEnterByXpath(prop.getProperty("EventMgnt.EditEventName.Xpath"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to modify the start date of an event
	public EditEventManagementPage selectStartDate(){
		setExplicitWaitEnterByXpath(prop.getProperty("EventMgnt.EditStartDate.Xpath"), propDatas.getProperty("eventMgnt.Edit.StartDate"));
		return this;
	}
	
	//This method is used to modify the End Date of an event
	public EditEventManagementPage selectEndDate(){
		setExplicitWaitEnterByXpath(prop.getProperty("EventMgnt.EditEndDate.Xpath"), propDatas.getProperty("eventMgnt.Edit.EndDate"));
		return this;
	}
	
	//This method is used to modify the no of days event going to be happen
	public EditEventManagementPage enterNoOfDays(){
		setExplicitWaitEnterByXpath(prop.getProperty("EventMgnt.EditNoOfDays.Xpath"), propDatas.getProperty("eventMgnt.Edit.NoOfDays"));
		return this;
	}
	
	//This method is used to modify the currency decimal 
	public EditEventManagementPage selectCurrencyDecimal(){
		selectVisibileTextByXPath(prop.getProperty("EventMgnt.EditCurrencyDecimal.Xpath"), propDatas.getProperty("eventMgnt.Edit.CurrencyDecimal"));
		return this;
	}
	
	
	//This method is used to click the Save Changes button
	public EditEventManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.EditSaveChanges.Xpath"));
		Thread.sleep(3000);
		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		return this;
	}
	
	//This method is used to verify the created Event is displayed in table or not
	public EditEventManagementPage verifyModifiedEvent(){
		driver.navigate().refresh();
		String actualProgramName=getTextByXpath(prop.getProperty("EventMgnt.GetEventName.Xpath"));
		String expectedProgramName=propDatas.getProperty("eventMgnt.Edit.EventName");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}
