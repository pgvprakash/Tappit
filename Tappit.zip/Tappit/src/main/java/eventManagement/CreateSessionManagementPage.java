package eventManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateSessionManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public CreateSessionManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateSessionManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateSessionManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateSessionManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateSessionManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateSessionManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateSessionManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Event Management sub menu
	public CreateSessionManagementPage clickEventManagement(){
		setExplicitWaitClickById(prop.getProperty("EventMgnt.EventMgnt.Id"));
		return this;
	}

	//This  method is used to click the edit icon from the existing event
	public CreateSessionManagementPage clickSessionIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Session.SessionIcon.Xpath"));
		return this;
	}
	
	//This method is used to click the Add Session link
	public CreateSessionManagementPage clickAddSession(){
		setExplicitWaitClickByLink(prop.getProperty("Session.AddSession.LinkText"));
		return this;
	}
	
	//This method is used to select the start time of a session
	public CreateSessionManagementPage enterStartTime()throws Exception{
		setExplicitWaitEnterByName(prop.getProperty("Session.StartTime.Name"), propDatas.getProperty("session.Create.StartTime"));
		return this;
	}
	
	//This method is used to select the end time of a session
	public CreateSessionManagementPage enterEndTime(){
		setExplicitWaitEnterByName(prop.getProperty("Session.EndTime.Name"), propDatas.getProperty("eventMgnt.Edit.EndDate"));
		return this;
	}
	
	//This method is used to enter the session name in given text field
	public CreateSessionManagementPage enterSessionName(){
		setExplicitWaitEnterByName(prop.getProperty("Session.SessionName.Name"), propDatas.getProperty("session.Create.SessionName"));
		return this;
	}
	//This method is used to select the Reset option from drop down list
	public CreateSessionManagementPage selectReset(){
		selectVisibileTextByValue(prop.getProperty("Session.Reset.Name"), propDatas.getProperty("session.Create.Reset"));
		return this;
	}
	
	//This method is used to select the Load Credit option from drop down list
	public CreateSessionManagementPage selectLoadCredit(){
		selectVisibileTextByValue(prop.getProperty("Session.LoadCredit.Name"), propDatas.getProperty("session.Create.LoadCredit"));
		return this;
	}
	
	//This method is used to select the reset access option from drop down list
	public CreateSessionManagementPage selectResetAccess(){
		selectVisibileTextByValue(prop.getProperty("Session.ResetAccess.Name"), propDatas.getProperty("session.Create.ResetAccess"));
		return this;
	}
	
	//This method is used to click the submit button
	public CreateSessionManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Session.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the created Event is displayed in table or not
	public CreateSessionManagementPage verifyCreatedEvent(){
		String actualSessionName=getTextByXpath(prop.getProperty("Session.SessionName.Xpath"));
		String expectedSessionName=propDatas.getProperty("session.Create.SessionName");
		assertVerification(actualSessionName, expectedSessionName);
		return this;
	}
}