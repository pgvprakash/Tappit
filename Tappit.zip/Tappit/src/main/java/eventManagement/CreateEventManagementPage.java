package eventManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateEventManagementPage extends Tappit{

	// This is to confirm you are in Login Page
	public CreateEventManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateEventManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateEventManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateEventManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateEventManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateEventManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateEventManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Event Management sub menu
	public CreateEventManagementPage clickEventManagement(){
		setExplicitWaitClickById(prop.getProperty("EventMgnt.EventMgnt.Id"));
		return this;
	}
	
	//This menu is used to click the Add Event link
	public CreateEventManagementPage clickAddEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Create.LinkText"));
		return this;
	}
	
	//This method is used to enter the event name in given text field
	public CreateEventManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.Name.Name"), propDatas.getProperty("eventMgnt.Create.Name"));
		return this;
	}
	
	//This method is used to enter the start date of the event
	public CreateEventManagementPage selectStartDate(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.StartDate.Name"), propDatas.getProperty("eventMgnt.Create.StartDate"));
		return this;
	}
	
	//This method is used to enter the end date of the event
	public CreateEventManagementPage selectEndDate(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.EndDate.Name"), propDatas.getProperty("eventMgnt.Create.EndDate"));
		return this;
	}
	
	//This method is used to enter the no of days event going to be run
	public CreateEventManagementPage enterNoOfDays(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.NoOfDays.Name"), propDatas.getProperty("eventMgnt.Create.NoOfDays"));
		return this;
	}
	
	//This method is used to select the currency code from the list
	public CreateEventManagementPage selectCurrencyCode(){
		selectVisibileTextByName(prop.getProperty("EventMgnt.currencyCode.Name"), propDatas.getProperty("eventMgnt.Create.CurrencyCode"));
		return this;
	}
	
	//This method is used to select the currency decimal from the drop down list
	public CreateEventManagementPage selectCurrencyDecimal(){
		selectVisibileTextByName(prop.getProperty("EventMgnt.currencyDecimal.Name"), propDatas.getProperty("eventMgnt.Create.CurrencyDecimal"));
		return this;
	}
	
	//This method is used to select the Time Zone from the drop down list
	public CreateEventManagementPage selectTimeZone(){
		selectVisibileTextByName(prop.getProperty("EventMgnt.TimeZone.Name"), propDatas.getProperty("eventMgnt.Create.TimeZone"));
		return this;
	}
	
	//This method is used to select the country code from the drop down list
	public CreateEventManagementPage selectCountryCode(){
		selectVisibileTextByName(prop.getProperty("EventMgnt.Country.Name"), propDatas.getProperty("eventMgnt.Create.Country"));
		return this;
	}
	
	//This method is used to select the maximum preload time
	public CreateEventManagementPage selectMaxPreLoadTime(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.MaxPreloadTime.Name"),propDatas.getProperty("eventMgnt.Create.MaxPreloadTime"));
		return this;
	}
	
	//This method is used to set the event sync time
	public CreateEventManagementPage setEventSyncTime(){
		setExplicitWaitEnterByName(prop.getProperty("EventMgnt.EventSyncTime.Name"), propDatas.getProperty("eventMgnt.Create.EventSyncTime"));
		return this;
	}
	
	//This method is used to click the Submit button after filling the add event form
	public CreateEventManagementPage clickSubmit() throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.Submit.Xpath"));
		Thread.sleep(5000);
//		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
//		Reporter.log(text,true);
		return this;
	}
	
	//This method is used to verify the created Event is displayed in table or not
	public CreateEventManagementPage verifyCreatedEvent(){
		String actualEventName=getTextByXpath(prop.getProperty("EventMgnt.GetEventName.Xpath"));
		String expectedEventName=propDatas.getProperty("eventMgnt.Create.Name");
		assertVerification(actualEventName, expectedEventName);
		return this;
	}
	
	//This method is used to show the table data's like 20/30/40
	public CreateEventManagementPage show(){
		String actualEndId=getTextByXpath(prop.getProperty("EventMgnt.EndId.Xpath"));
		selectByValueXpath(prop.getProperty("EventMgnt.Show.Xpath"), propDatas.getProperty("pgmMgnt.Show.Value"));
		String expectedEndId=getTextByXpath(prop.getProperty("EventMgnt.ShowEndId.Xpath"));
		Assert.assertNotEquals(actualEndId, expectedEndId);
		return this;
	}
	
	//This method is used to verify the next link in bottom of the page
	public CreateEventManagementPage next(){
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.Next.Xpath"));
		return this;
	}
	
	//This method is used to verify the Previous link in bottom of the page
	public CreateEventManagementPage previous(){
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.Previous.Xpath"));
		return this;
	}
}
