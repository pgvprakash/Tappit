package cardManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class SearchCards extends Tappit{
	
	// This is to confirm you are in Login Page
	public SearchCards(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public SearchCards acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the user name in given text field
	public SearchCards enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public SearchCards enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public SearchCards selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public SearchCards clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public SearchCards clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Card Management Menu
	public SearchCards clickCardManagement(){
		setExplicitWaitClickById(prop.getProperty("Card.Menu.Id"));
		return this;
	}
	
	//This method is used to enter the CID in search field
	public SearchCards enterCid(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.SearchCid.Xpath"), propDatas.getProperty("Lot.Upload.Cards"));
		return this;
	}
	
	//This method is used to click the filter button
	public SearchCards clickFilter(){
		setExplicitWaitClickByXpath(prop.getProperty("Card.Filter.Xpath"));
		return this;
	}
	
	//This method is used to search the newly added card in card management
	public SearchCards verifyCID(){
		String actualCardName=getTextByXpath(prop.getProperty("Card.CID.Xpath"));
		String expectedCardName=propDatas.getProperty("Lot.Upload.Cards");
		assertVerification(actualCardName, expectedCardName);
		return this;
	}
}
