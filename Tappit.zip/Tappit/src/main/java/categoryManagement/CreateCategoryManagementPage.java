package categoryManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateCategoryManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateCategoryManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateCategoryManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateCategoryManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateCategoryManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateCategoryManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateCategoryManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateCategoryManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Category Management sub menu
	public CreateCategoryManagementPage clickCategoryManagement(){
		setExplicitWaitClickById(prop.getProperty("Category.MenuLink.Id"));
		return this;
	}
	
	//This method is used to click the Add Category link
	public CreateCategoryManagementPage clickAddCategory(){
		setExplicitWaitClickByLink(prop.getProperty("Category.AddCategory.LinkText"));
		return this;
	}
	
	//This method is used to enter the category name in the given field
	public CreateCategoryManagementPage enterCategory(){
		setExplicitWaitEnterByName(prop.getProperty("Category.CategoryName.Name"), propDatas.getProperty("Category.Create.Name"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateCategoryManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Category.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
}
