package outletManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditOutletManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public EditOutletManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditOutletManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditOutletManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditOutletManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public EditOutletManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditOutletManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public EditOutletManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public EditOutletManagementPage clickOutletManagement(){
		setExplicitWaitClickById(prop.getProperty("OutletMgnt.Menu.Id"));
		return this;
	}
	
	 //This method is used to filter the Created Outlet
	 public EditOutletManagementPage filterOutlet()throws Exception{
		 setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.SearchOutletName.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		 setExplicitWaitClickById(prop.getProperty("OutletMgnt.Filter.Id"));
		 Thread.sleep(3000);
		 return this;
	 }
	 
	 //This method is used to click the edit button
	 public EditOutletManagementPage clickEdit(){
		 setExplicitWaitClickByXpath(prop.getProperty("OutletMgnt.EditIcon.Xpath"));
		 return this;
	 }
	 
	 //This method is used to modify the city field in existing outlet
	 public EditOutletManagementPage editCity(){
		 setExplicitWaitEnterByXpath(prop.getProperty("OutletMgnt.EditCity.Xpath"), propDatas.getProperty("outlet.Edit.City"));
		 return this;
	 }
	 
	 //This method is used to modify the Sate field in existing outlet
	 public EditOutletManagementPage editState(){
		 setExplicitWaitEnterByXpath(prop.getProperty("OutletMgnt.EditState.Xpath"), propDatas.getProperty("outlet.Edit.State"));
		 return this;
	 }
	 
	 //This method is used to modify the outlet owner field in existing outlet
	 public EditOutletManagementPage editOutletOwner(){
		 setExplicitWaitEnterByXpath(prop.getProperty("OutletMgnt.EditOutletOwner.Xpath"), propDatas.getProperty("outlet.Edit.OutletOwner"));
		 return this;
	 }
	 
	 //This method is used to click the Save Changed button
	 public EditOutletManagementPage clickSaveChanges()throws Exception{
		 setExplicitWaitClickByXpath(prop.getProperty("OutletMgnt.SaveChanges.Xpath"));
		 Thread.sleep(3000);
		 return this;
	 }
	 
	 //This method is used to verify the created outlet
	 public EditOutletManagementPage verifySuccessAlert(){
		String actualMessage=getTextByXpath(prop.getProperty("OutletMgnt.SuccessAlert.Xpath"));
		Assert.assertTrue(actualMessage.contains("Outlet successfully updated"));
		return this;
	 }

}
