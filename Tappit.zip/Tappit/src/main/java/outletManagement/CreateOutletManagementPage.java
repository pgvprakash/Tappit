package outletManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateOutletManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateOutletManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateOutletManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateOutletManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateOutletManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateOutletManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateOutletManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateOutletManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Outlet Management sub menu
	public CreateOutletManagementPage clickOutletManagement(){
		setExplicitWaitClickById(prop.getProperty("OutletMgnt.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Add Outlet link
	public CreateOutletManagementPage clickAddOutlet(){
		setExplicitWaitClickByLink(prop.getProperty("OutletMgnt.AddOutlet.LinkText"));
		return this;
	}
	
	//This method is used to enter the Outlet Name in given text field
	public CreateOutletManagementPage enterOutletName(){
		setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.OutletName.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to enter the city name in the given text field
	public CreateOutletManagementPage enterCity(){
		setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.City.Name"), propDatas.getProperty("outlet.Create.City"));
		return this;
	}
	
	//This method is used to enter the State name in the given text field 
	public CreateOutletManagementPage enterState(){
		setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.State.Name"), propDatas.getProperty("outlet.Create.State"));
		return this;
	}
	
	//This method is used to select the Parent Id(Area) from the given drop down list. Here Area name(outlet.Create.State) will come from area mgnt
	 public CreateOutletManagementPage selectParentId(){
		 selectVisibileTextById(prop.getProperty("OutletMgnt.ParentId.Id"), propDatas.getProperty("area.Create.Name"));
		 return this;
	 }
	 
	 //This method is used to enter the outlet owner name in the given text field
	 public CreateOutletManagementPage enterOutletOwner(){
		 setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.OutletOwner.Name"), propDatas.getProperty("outlet.Create.OutletOwner"));
		 return this;
	 }
	 
	 //This method is used to click the submit button
	 public CreateOutletManagementPage clickSubmit()throws Exception{
		 setExplicitWaitClickByXpath(prop.getProperty("OutletMgnt.Submit.Xpath"));
		 Thread.sleep(3000);
		 return this;
	 }
	 
	 //This method is used to filter the Created Outlet
	 public CreateOutletManagementPage filterOutlet()throws Exception{
		 setExplicitWaitEnterByName(prop.getProperty("OutletMgnt.SearchOutletName.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		 setExplicitWaitClickById(prop.getProperty("OutletMgnt.Filter.Id"));
		 Thread.sleep(3000);
		 return this;
	 }
	 
	 //This method is used to verify the created outlet
	 public CreateOutletManagementPage verifyOutlet(){
		String actualOutletName=getTextByXpath(prop.getProperty("OutletMgnt.VerifyOutletName.Xpath"));
		String expectedOutletName=propDatas.getProperty("outlet.Create.OutletName");
		assertVerification(actualOutletName, expectedOutletName);		 
		return this;
	 }
}
