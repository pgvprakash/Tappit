package currencyManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditCurrencyManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditCurrencyManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditCurrencyManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditCurrencyManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditCurrencyManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditCurrencyManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditCurrencyManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public EditCurrencyManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Currency Management menu
	public EditCurrencyManagementPage clickCurrencyManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.CurrMgnt.Id"));
		return this;
	}
	
	//This method is used to edit the existing currency management
	public EditCurrencyManagementPage clickEdit(){
		setExplicitWaitClickByXpath(prop.getProperty("CurrMgnt.Edit.Xpath"));
		return this;
	}
	
	//This method is used to modify the existing account name in currency management
	public EditCurrencyManagementPage editAccountName(){
		setExplicitWaitEnterByXpath(prop.getProperty("CurrMgnt.EditAccountName.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to modify the existing currency symbol in currency management
	public EditCurrencyManagementPage editCurrencySymbol() throws Exception{
		setExplicitWaitEnterByXpath(prop.getProperty("CurrMgnt.EditCurrencySymbol.Xpath"), propDatas.getProperty("CurrMgnt.Edit.CurrencySymbol"));
		Thread.sleep(2000);
		return this;
	}
		
	//This method is used to choose the real currency check box
	public EditCurrencyManagementPage clickRealCurrency(){
		setExplicitWaitClickByName(prop.getProperty("CurrMgnt.EditRealCurrency.Xpath"));
		return this;
	}
	
	//This method is used to modify the existing Currency Code from the list
	public EditCurrencyManagementPage editCurrencyCode(){
		selectVisibileTextByXPath(prop.getProperty("CurrMgnt.EditCurrencyCode.Xpath"), propDatas.getProperty("CurrMgnt.Edit.CurrencyCode"));
		return this;
	}
	
	//This method is used to modify the existing allowed decimal
	public EditCurrencyManagementPage editAllowedDecimal(){
		setExplicitWaitEnterByXpath(prop.getProperty("CurrMgnt.EditAllowedDecimal.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AllowedDecimal"));
		return this;
	}
	
	//This method is used to Save the modified details
	public EditCurrencyManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("CurrMgnt.EditSaveChanges.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the success message after Save Changes
	public EditCurrencyManagementPage successMessage(){
		String actualProgramName=getTextByXpath(prop.getProperty("CurrMgnt.SuccessMessage.Xpath"));
		String expectedProgramName=propDatas.getProperty("CurrMgnt.Edit.SuccessMessage");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
	
	//This method is used to verify the updated currency
	public EditCurrencyManagementPage verifyAccountName(){
		driver.navigate().refresh();
		String actualProgramName=getTextByXpath(prop.getProperty("CurrMgnt.AccountName.Xpath"));
		String expectedProgramName=propDatas.getProperty("CurrMgnt.Edit.AccountName");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}