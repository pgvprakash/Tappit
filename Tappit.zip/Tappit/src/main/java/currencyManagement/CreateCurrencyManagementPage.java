package currencyManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateCurrencyManagementPage extends Tappit{	
	
	// This is to confirm you are in Login Page
	public CreateCurrencyManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateCurrencyManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateCurrencyManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateCurrencyManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateCurrencyManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateCurrencyManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateCurrencyManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Currency Management menu
	public CreateCurrencyManagementPage clickCurrencyManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.CurrMgnt.Id"));
		return this;
	}
	
	//This method is used to click the add currency in currency management
	public CreateCurrencyManagementPage clickAddCurrency(){
		setExplicitWaitClickByLink(prop.getProperty("CurrMgnt.AddCurrency.LinkText"));
		return this;
	}
	
	//This method is used to Enter the account name in the given field
	public CreateCurrencyManagementPage enterAccountName(){
		setExplicitWaitEnterByName(prop.getProperty("CurrMgnt.Name.Name"), propDatas.getProperty("CurrMgnt.Create.AccountName"));
		return this;
	}
	
	//This method is used to enter the Currency Symbol in the given field
	public CreateCurrencyManagementPage enterCurrencySymbol(){
		setExplicitWaitEnterByName(prop.getProperty("CurrMgnt.CurrencySymbol.Name"), propDatas.getProperty("CurrMgnt.Create.CurrencySymbol"));
		return this;
	}
	
	//This method is used to select the currency type in the given list
	public CreateCurrencyManagementPage selectCurrencyType(){
		selectVisibileTextByName(prop.getProperty("CurrMgnt.CurrencyType.Name"), propDatas.getProperty("CurrMgnt.Create.CurrencyType"));
		return this;
	}
	
	//This method is used to select the Currency Code from the list
	public CreateCurrencyManagementPage selectCurrencyCode(){
		selectVisibileTextByName(prop.getProperty("CurrMgnt.CurrencyCode.Name"), propDatas.getProperty("CurrMgnt.Create.CurrencyCode"));
		return this;
	}
	
	//This method is used to select the Allowed Decimal from the list
	public CreateCurrencyManagementPage enterDecimal(){
		setExplicitWaitEnterByName(prop.getProperty("CurrMgnt.AllowDecimal.Name"), propDatas.getProperty("CurrMgnt.Create.AllowedDecimal"));
		return this;
	}
	
	//This method is used to Click the Submit button
	public CreateCurrencyManagementPage clickSubmit() throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("CurrMgnt.SubmitButton.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the newly created currency
	public CreateCurrencyManagementPage verifyAccountName(){
		driver.navigate().refresh();
		String actualProgramName=getTextByXpath(prop.getProperty("CurrMgnt.AccountName.Xpath"));
		String expectedProgramName=propDatas.getProperty("CurrMgnt.Create.AccountName");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}