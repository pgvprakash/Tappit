package gateManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateGateManagementPage extends Tappit{
	
	//This is to confirm you are in Login Page
	public CreateGateManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateGateManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateGateManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateGateManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateGateManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateGateManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateGateManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Gate Management sub menu
	public CreateGateManagementPage clickGateManagement(){
		setExplicitWaitClickById(prop.getProperty("Gate.Menu.Id"));
		return this;
	}
	
	//This menu is used to click the Add Gate link
	public CreateGateManagementPage clickAddGate(){
		setExplicitWaitClickByLink(prop.getProperty("Gate.AddGate.LinkText"));
		return this;
	}
	
	//This method is used to enter the Gate Name
	public CreateGateManagementPage enterGateName(){
		setExplicitWaitEnterByName(prop.getProperty("Gate.GateName.Name"), propDatas.getProperty("gate.Create.GateName"));
		return this;
	}
	
	//This method is used to select the event name from the drop down list
	public CreateGateManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("Gate.SelectEvent.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to select the area name from the drop down list
	public CreateGateManagementPage selectArea(){
		selectVisibileTextByName(prop.getProperty("Gate.EntryArea.Name"), propDatas.getProperty("area.Create.Name"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateGateManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Gate.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to show the table data's like 20/30/40
	public CreateGateManagementPage show(){
		selectByValueXpath(prop.getProperty("EventMgnt.Show.Xpath"), propDatas.getProperty("gate.Show.Value"));
		return this;
	}
	
	//This method is used to filter the created gate
	public CreateGateManagementPage verifyGate(){
		String actualGateName=getTextByXpath(prop.getProperty("Gate.VerifyGateName.Xpath"));
		String expectedGateName=propDatas.getProperty("gate.Create.GateName");
		assertVerification(actualGateName, expectedGateName);		 
		return this;
	}
}
