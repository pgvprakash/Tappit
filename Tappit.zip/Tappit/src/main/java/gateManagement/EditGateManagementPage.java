package gateManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditGateManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public EditGateManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditGateManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditGateManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditGateManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public EditGateManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditGateManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditGateManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Gate Management sub menu
	public EditGateManagementPage clickGateManagement(){
		setExplicitWaitClickById(prop.getProperty("Gate.Menu.Id"));
		return this;
	}
	
	//This method is used to show the table data's like 20/30/40
	public EditGateManagementPage show(){
		selectByValueXpath(prop.getProperty("EventMgnt.Show.Xpath"), propDatas.getProperty("gate.Show.Value"));
		return this;
	}
	
	//This method is used to filter the created gate
	public EditGateManagementPage clickEdit(){
		setExplicitWaitClickByXpath(prop.getProperty("Gate.EditIcon.Xpath"));		 
		return this;
	}
	
	//This method is used to modify the existing gate name in given text field
	public EditGateManagementPage editGateName(){
		setExplicitWaitEnterByXpath(prop.getProperty("Gate.GateName.Xpath"), propDatas.getProperty("gate.Edit.GateName"));
		return this;
	}
	
	//This method is used to click the Save Changes button
	public EditGateManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Gate.SaveChanges.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	 //This method is used to verify the created outlet
	 public EditGateManagementPage verifySuccessAlert(){
		String actualMessage=getTextByXpath(prop.getProperty("OutletMgnt.SuccessAlert.Xpath"));
		Assert.assertTrue(actualMessage.contains("Gate successfully updated"));
		return this;
	 }
}
