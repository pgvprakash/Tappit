package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;


public class EditProgramManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditProgramManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditProgramManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditProgramManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditProgramManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditProgramManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(5000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditProgramManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public EditProgramManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public EditProgramManagementPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This method is used to click the Edit icon inside the table
	public EditProgramManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.Edit.Xpath"));
		return this;
	}
	
	//This method is used to update the program name
	public EditProgramManagementPage editProgramName(){
		setExplicitWaitEnterByXpath(prop.getProperty("PgmMgnt.EditName.Xpath"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to update the pin number
	public EditProgramManagementPage editPin(){
		setExplicitWaitEnterByXpath(prop.getProperty("PgmMgnt.EditPin.Xpath"), propDatas.getProperty("pgmMgnt.Edit.Pin"));
		return this;
	}
	
	//This method is used to select the Program Status option from drop down list
	public EditProgramManagementPage editProgramStatus(){
		selectByValueXpath(prop.getProperty("PgmMgnt.EditProgramStatus.Xpath"), propDatas.getProperty("pgmMgnt.Edit.ProgramStatus"));
		return this;
	}
	
	//This method is used to update the pre-load details
	public EditProgramManagementPage editPreLoad(){
		selectVisibileTextByXPath(prop.getProperty("PgmMgnt.EditAllowPreLoad.Xpath"), propDatas.getProperty("pgmMgnt.Edit.PreLoad"));
		setExplicitWaitClickByXpath(prop.getProperty("common.InformationPopup.Xpath"));
		return this;
	}
	
	//This method is used to click the Save Changes button
	public EditProgramManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.SaveChanges.Xpath"));
		Thread.sleep(5000);
		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		return this;
	}
	
	//This method is used to verify the modified program is displayed in table or not
	public EditProgramManagementPage verifyupdatedProgram(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmMgnt.GetProgramName.Xpath"));
		String expectedProgramName=propDatas.getProperty("pgmMgnt.Edit.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}
