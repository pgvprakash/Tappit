package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class CreateProgramFeesMgntPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateProgramFeesMgntPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateProgramFeesMgntPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateProgramFeesMgntPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateProgramFeesMgntPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateProgramFeesMgntPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateProgramFeesMgntPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateProgramFeesMgntPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public CreateProgramFeesMgntPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This method is used to click the Add Program Fees icon inside the table
	public CreateProgramFeesMgntPage clickAddProgramFeeIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmFeeMgnt.Add.Xpath"));
		return this;
	}
	
	//This method is used to click the Add Program Fees link
	public CreateProgramFeesMgntPage clickAddProgramFeeLink() {
		setExplicitWaitClickByLink(prop.getProperty("PgmFeeMgnt.AddPgmFees.LinkText"));
		return this;
	}
	
	//This method is used to enter the Program fees name in the given field
	public CreateProgramFeesMgntPage enterProgramFeeName(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.Name.Name"), propDatas.getProperty("pgmFeeMgnt.Add.Name"));
		return this;
	}
	
	//This method is used to select the fees type from the given drop down list
	public CreateProgramFeesMgntPage selectFeesType(){
		selectVisibileTextByName(prop.getProperty("PgmFeeMgnt.FeesType.Name"), propDatas.getProperty("pgmFeeMgnt.Add.FeesType"));
		return this;
	}
	
	//This method is used to select the account name from the list
	public CreateProgramFeesMgntPage selectAccountName(){
		selectVisibileTextByName(prop.getProperty("PgmFeeMgnt.AccountName.Name"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to enter the fixed fee in the given text field
	public CreateProgramFeesMgntPage enterFixedFee(){
		setExplicitWaitEnterByName(prop.getProperty("PgmFeeMgnt.FixedFee.Name"), propDatas.getProperty("pgmFeeMgnt.Add.FixedFee"));
		return this;
	}
	
	//This method is used to enter the fixed fee in the given text field
	public CreateProgramFeesMgntPage enterFeeRate(){
		setExplicitWaitEnterByName(prop.getProperty("PgmFeeMgnt.FeeRate.Name"), propDatas.getProperty("pgmFeeMgnt.Add.FeeRate"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateProgramFeesMgntPage clickSubmitButton() throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.SubmitButton.Xpath"));
		Thread.sleep(4000);
		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		return this;
	}
	
	//This method is used to verify the created program fee is displayed in table or not
	public CreateProgramFeesMgntPage verifyCreatedProgramFees(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmFeeMgnt.CreatedProgramFeeName.Xpath"));
		String expectedProgramName=propDatas.getProperty("pgmFeeMgnt.Add.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
}
