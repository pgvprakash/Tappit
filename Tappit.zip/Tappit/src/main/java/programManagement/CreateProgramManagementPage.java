package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateProgramManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public CreateProgramManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateProgramManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateProgramManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateProgramManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateProgramManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateProgramManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateProgramManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public CreateProgramManagementPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This menu is used to click the Add Program link
	public CreateProgramManagementPage clickAddProgram(){
		setExplicitWaitClickByLink(prop.getProperty("PgmMgnt.AddPgm.LinkText"));
		return this;
	}
	
	//This method is used to enter the program name in given text field
	public CreateProgramManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.Name.Name"), propDatas.getProperty("pgmMgnt.Create.Name"));
		return this;
	}
	
	//This method is used to enter the description in given text field
	public CreateProgramManagementPage enterDescription(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.Description.Name"), propDatas.getProperty("pgmMgnt.Create.Description"));
		return this;
	}
	
	//This method is used to enter the pin in the given text field
	public CreateProgramManagementPage enterPin(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.Pin.Name"), propDatas.getProperty("pgmMgnt.Create.Pin"));
		return this;
	}
	
	//This method is used to select the mode from drop down list
	public CreateProgramManagementPage selectMode(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.Mode.Name"), propDatas.getProperty("pgmMgnt.Create.Mode"));
		return this;
	}
	
	//This method is used to select the event name from the list
	public CreateProgramManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.EventName.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to select the base currency from drop down list
	public CreateProgramManagementPage selectBasaeCurrency(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.BaseCurrency.Name"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to select the currency type from the list
	public CreateProgramManagementPage selectCurrencyType(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.CurrencyType.Name"), propDatas.getProperty("pgmMgnt.Create.CurrencyType"));
		return this;
	}
	
	//This method is used to enter the spend order in given field
	public CreateProgramManagementPage enterSpendOrder(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.SpendOrder.Name"), propDatas.getProperty("pgmMgnt.Create.SpendOrder"));
		return this;
	}
	
	//This method is used to click the cashout checkbox
	public CreateProgramManagementPage clickCashout(){
		setExplicitWaitClickByName(prop.getProperty("PgmMgnt.CashoutCheck.Name"));
		return this;
	}
	
	//This method is used to click the Minimum Spend checkbox
	public CreateProgramManagementPage clickMinSpend(){
		setExplicitWaitClickByName(prop.getProperty("PgmMgnt.MinSpend.Name"));
		return this;
	}
	
	//This methos is used to click the preload checkbox
	public CreateProgramManagementPage clickPreload(){
		setExplicitWaitClickByName(prop.getProperty("PgmMgnt.Preload.Name"));
		return this;
	}
	//This method is used to select the card type from drop down list
	public CreateProgramManagementPage selectCardType(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.Cardtype.Name"), propDatas.getProperty("pgmMgnt.Create.CardType"));
		return this;
	}
	
	//This method is used to select the verification field from list area
	public CreateProgramManagementPage selectVerificationField(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.VerifiCationField.Name"), propDatas.getProperty("pgmMgnt.Create.VerificationField"));
		return this;
	}
	
	//This method is used to select the Program Status option from drop down list
	public CreateProgramManagementPage selectProgramStatus(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.ProgramStatus.Name"), propDatas.getProperty("pgmMgnt.Create.ProgramStatus"));
		return this;
	}
	
	//This method is used to select the PreLoad option from drop down list
	public CreateProgramManagementPage selectPreLoad(){
		selectVisibileTextByName(prop.getProperty("PgmMgnt.PreLoad.Name"), propDatas.getProperty("pgmMgnt.Create.PreLoad"));
		return this;
	}
	
	//This method is used to select the KYC from the drop down list
	public CreateProgramManagementPage selectKYC(){
		selectVisibileTextByXPath(prop.getProperty("PgmMgnt.KYC.Xpath"), propDatas.getProperty("pgmMgnt.Create.KYC"));
		return this;
	}
	
	//This method is used to enter the KYC amount in given text field
	public CreateProgramManagementPage enterKycAmount(){
		setExplicitWaitEnterByName(prop.getProperty("PgmMgnt.KycAmount.Name"), propDatas.getProperty("pgmMgnt.Create.KYCAmount"));
		return this;
	}
	
	//This method is used to click the Add KYC button
	public CreateProgramManagementPage clickAddKycAmountButton() {
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.AddKycAmountButton.Xpath"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateProgramManagementPage clickSubmitButton() throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.SubmitButton.Xpath"));
//		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
//		Reporter.log(text,true);
		Thread.sleep(4000);
		driver.navigate().refresh();
		return this;
	}
	 
	//This method is used to verify the created program is displayed in table or not
	public CreateProgramManagementPage verifyCreatedProgram(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmMgnt.GetProgramName.Xpath"));
		String expectedProgramName=propDatas.getProperty("pgmMgnt.Create.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
	
	//This method is used to Verify the Filter selection
	public CreateProgramManagementPage selectFilter(){
		selectByValueXpath(prop.getProperty("PgmMgnt.ProgramStatus.Xpath"), propDatas.getProperty("pgmMgnt.Filter.Value"));
		return this;
	}
	
	//This method is used to click the Filter button
	public CreateProgramManagementPage clickFilter(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.FilterButton.Xpath"));
		return this;
	}
	
	//This method is used to verify the created program is displayed in table or not
	public CreateProgramManagementPage verifyStatus(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmMgnt.Status.Xpath"));
		String expectedProgramName="Inactive";
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
	
	//This method is used to click the clear button
	public CreateProgramManagementPage clickClear(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.ClearButton.Xpath"));
		return this;
	}
	
	//This method is used to verify the created program is displayed in table or not
	public CreateProgramManagementPage verifyStatusAfterClearFilter(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmMgnt.Status.Xpath"));
		String expectedProgramName="Inactive";
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
	
	public CreateProgramManagementPage show(){
		String actualEndId=getTextByXpath(prop.getProperty("PgmMgnt.EndId.Xpath"));
		selectByValueXpath(prop.getProperty("PgmMgnt.Show.Xpath"), propDatas.getProperty("pgmMgnt.Show.Value"));
		String expectedEndId=getTextByXpath(prop.getProperty("PgmMgnt.ShowEndId.Xpath"));
		Assert.assertNotEquals(actualEndId, expectedEndId);
		return this;
	}
	
	//This method is used to verify the next link in bottom of the page
	public CreateProgramManagementPage next(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.Next.Xpath"));
		return this;
	}
	
	//This method is used to verify the Previous link in bottom of the page
	public CreateProgramManagementPage previous(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmMgnt.Previous.Xpath"));
		return this;
	}
}