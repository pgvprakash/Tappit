package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateProgramLimitsMgntPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public CreateProgramLimitsMgntPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateProgramLimitsMgntPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateProgramLimitsMgntPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateProgramLimitsMgntPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateProgramLimitsMgntPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateProgramLimitsMgntPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateProgramLimitsMgntPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public CreateProgramLimitsMgntPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This method is used to click the Add icon from the Program Management home screen
	public CreateProgramLimitsMgntPage clickAdd(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmLimitMgnt.AddIcon.Xpath"));
		return this;
	}
	
	//This method is used to click the Add Program Limit management
	public CreateProgramLimitsMgntPage clickAddProgramLimit(){
		setExplicitWaitClickByLink(prop.getProperty("PgmLimitMgnt.AddPgmLimit.LinkText"));
		return this;
	}
	
	//This method is used to enter the name in the given field
	public CreateProgramLimitsMgntPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("PgmLimitMgnt.Name.Name"), propDatas.getProperty("pgmLmtMgnt.Create.Name"));
		return this;
	}
	
	//This method is used to select the account name from the list
	public CreateProgramLimitsMgntPage selectAccountName(){
		selectVisibileTextByName(prop.getProperty("PgmLimitMgnt.AccountName.Name"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to select the limit type from the list
	public CreateProgramLimitsMgntPage selectLimitType(){
		selectVisibileTextByName(prop.getProperty("PgmLimitMgnt.LimitType.Name"), propDatas.getProperty("pgmLmtMgnt.Create.LimitType"));
		return this;
	}
	
	//This method is used to enter the maximum amount
	public CreateProgramLimitsMgntPage enterMaxAmount(){
		setExplicitWaitEnterByName(prop.getProperty("PgmLimitMgnt.MaxAmount.Name"), propDatas.getProperty("pgmLmtMgnt.Create.MaxAmount"));
		return this;
	}
	
	//This method is used to enter the minimum amount
	public CreateProgramLimitsMgntPage enterMinAmount(){
		setExplicitWaitEnterByName(prop.getProperty("PgmLimitMgnt.MinAmount.Name"), propDatas.getProperty("pgmLmtMgnt.Create.MinAmount"));
		return this;
	}
	
	//This method is used to enter the lifetime count in given field
	public CreateProgramLimitsMgntPage enterLifeTimeCount(){
		setExplicitWaitEnterByName(prop.getProperty("PgmLimitMgnt.LifeTimeCount.Name"), propDatas.getProperty("pgmLmtMgnt.Create.LifeTimeCount"));
		return this;
	}
	
	//This method is used to enter the lifetime amount in given field
	public CreateProgramLimitsMgntPage enterLifeTimeAmount(){
		setExplicitWaitEnterByName(prop.getProperty("PgmLimitMgnt.LifeTimeAmount.Name"), propDatas.getProperty("pgmLmtMgnt.Create.LifeTimeAmount"));
		return this;
	}
	
	//This method is used to Submit the Program Limit Management
	public CreateProgramLimitsMgntPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("PgmLimitMgnt.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
}