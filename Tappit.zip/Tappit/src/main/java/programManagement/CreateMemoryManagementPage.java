package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateMemoryManagementPage extends Tappit{

	// This is to confirm you are in Login Page
	public CreateMemoryManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateMemoryManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateMemoryManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateMemoryManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public CreateMemoryManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateMemoryManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public CreateMemoryManagementPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public CreateMemoryManagementPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This method is used to click the Add Memory Management Icon from the Grid
	public CreateMemoryManagementPage clickAddIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("MemoryMgnt.AddIcon.Xpath"));
		return this;
	}
	
	//This method is used to enter the Starting Memory 
	public CreateMemoryManagementPage enterStartingMemory(){
		setExplicitWaitEnterByName(prop.getProperty("MemoryMgnt.StartingMemory.Name"), propDatas.getProperty("memoryMgnt.Create.StartMemory"));
		return this;
	}
	
	//This method is used to click the POS check box
	public CreateMemoryManagementPage clickPOSApp(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.POS.Name"));
		return this;
	}
	
	//This method is used to click the Load App checkbox
	public CreateMemoryManagementPage clickLoadApp(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.Load.Name"));
		return this;
	}
	
	//This method is used to click the Access App checkbox
	public CreateMemoryManagementPage clickAccessApp(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.Access.Name"));
		return this;
	}
	
	//This method is used to click the QR Load Checkbox
	public CreateMemoryManagementPage clickQRLoad(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.QRLoad.Name"));
		return this;
	}
	
	//This method is used to click the Deposit checkbox
	public CreateMemoryManagementPage clickDeposit(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.Deposit.Name"));
		return this;
	}
	
	//This method is used to click the unload Deposit checkbox
	public CreateMemoryManagementPage clickUnloadDeposit(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.UnloadDeposit.Name"));
		return this;
	}
	
	//This method is used to click the access checkbox
	public CreateMemoryManagementPage clickAccess(){
		setExplicitWaitClickById(prop.getProperty("MemoryMgnt.Access.Id"));
		return this;
	}
	
	//This method is used to click the access time checkbox
	public CreateMemoryManagementPage clickAccessTimer(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.AccessTimer.Name"));
		return this;
	}
	
	//This method is used to click the terminal id checkbox
	public CreateMemoryManagementPage clickTerminalId(){
		setExplicitWaitClickByName(prop.getProperty("MemoryMgnt.TerminalId.Name"));
		return this;
	}
	
	//This method is used to click the Generate button
	public CreateMemoryManagementPage clickGenerate()throws Exception{
		setExplicitWaitClickById(prop.getProperty("MemoryMgnt.Generate.Id"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the genereate memory
	public CreateMemoryManagementPage verifySuccess(){
		String actualProgramName=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		String expectedProgramName=propDatas.getProperty("memoryMgnt.Create.SuccessMessage");
		assertVerify(actualProgramName, expectedProgramName);
		return this;
	}
}
