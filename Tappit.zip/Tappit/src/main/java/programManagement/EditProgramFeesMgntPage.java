package programManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class EditProgramFeesMgntPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditProgramFeesMgntPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditProgramFeesMgntPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditProgramFeesMgntPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditProgramFeesMgntPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public EditProgramFeesMgntPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditProgramFeesMgntPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Inventory menu link
	public EditProgramFeesMgntPage clickInventory(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Inventory.LinkText"));
		return this;
	}
	
	//This method is used to click the Program Management sub menu
	public EditProgramFeesMgntPage clickProgramManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.PgmMgnt.Id"));
		return this;
	}
	
	//This method is used to click the Add Program Fees icon inside the table
	public EditProgramFeesMgntPage clickAddProgramFeeIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("PgmFeeMgnt.Add.Xpath"));
		return this;
	}
	
	//This method is used to click the Edit icon inside the table
	public EditProgramFeesMgntPage clickEditIcon() {
		setExplicitWaitClickByXpath(prop.getProperty("PgmFeeMgnt.Edit.Xpath"));
		return this;
	}
	
	//This method is used to update the program name
	public EditProgramFeesMgntPage editProgramFeeName(){
		setExplicitWaitEnterByXpath(prop.getProperty("PgmFeeMgnt.EditName.Xpath"), propDatas.getProperty("pgmFeeMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to update the pin number
	public EditProgramFeesMgntPage editFixedFee(){
		setExplicitWaitEnterByXpath(prop.getProperty("PgmFeeMgnt.EditFixedFee.Xpath"), propDatas.getProperty("pgmFeeMgnt.Edit.FixedFee"));
		return this;
	}
	
	//This method is used to click the Save Changes button
	public EditProgramFeesMgntPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("PgmFeeMgnt.SaveChanges.Xpath"));
		Thread.sleep(5000);
		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		return this;
	}
	
	//This method is used to verify the created program is displayed in table or not
	public EditProgramFeesMgntPage verifyupdatedProgram(){
		String actualProgramName=getTextByXpath(prop.getProperty("PgmFeeMgnt.GetProgramFeeName.Xpath"));
		String expectedProgramName=propDatas.getProperty("pgmFeeMgnt.Edit.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}

}
