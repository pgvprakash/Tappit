package fleetManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateFleetManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateFleetManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateFleetManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateFleetManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateFleetManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateFleetManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateFleetManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateFleetManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Fleet Management sub menu
	public CreateFleetManagementPage clickFleetManagement(){
		setExplicitWaitClickById(prop.getProperty("Fleet.Menu.Id"));
		return this;
	}
	
	//This method is used to click the Add Fleet link
	public CreateFleetManagementPage clickAddFleet(){
		setExplicitWaitClickByLink(prop.getProperty("Fleet.AddFleet.LinkText"));
		return this;
	}
	
	//This method is used to enter the fleet name in the given field
	public CreateFleetManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Fleet.Name.Name"), propDatas.getProperty("Fleet.Create.Name"));
		return this;
	}
	
	//This method is used to select the outlet name from the list
	public CreateFleetManagementPage selectOutlet(){
		selectVisibileTextByName(prop.getProperty("Fleet.Outlet.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to select the device Profile from the list
	public CreateFleetManagementPage selectProfile(){
		selectVisibileTextByName(prop.getProperty("Fleet.DeviceProfile.Name"), propDatas.getProperty("Device.Create.Name"));
		return this;
	}
	
	//This method is used to select the Gate from the list
	public CreateFleetManagementPage selectGate(){
		selectVisibileTextByName(prop.getProperty("Fleet.Gate.Name"), propDatas.getProperty("gate.Edit.GateName"));
		return this;
	}
	
	//This method is used to click the Submit button 
	public CreateFleetManagementPage clickSubmit()throws Exception {
		setExplicitWaitClickByXpath(prop.getProperty("Fleet.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}

}
