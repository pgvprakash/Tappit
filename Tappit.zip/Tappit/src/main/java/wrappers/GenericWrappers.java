package wrappers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import com.relevantcodes.extentreports.ExtentTest;

public class GenericWrappers extends utils.Reporter implements Wrappers {

	public RemoteWebDriver driver;
	protected static Properties prop;
	protected static Properties propDatas;
	public String sUrl,primaryWindowHandle,sHubUrl,sHubPort,url,browsers;
	public static final int WAIT_TIME = 5;

	
	public GenericWrappers() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/main/resources/config.properties")));
			sHubUrl = prop.getProperty("HUB");
			sHubPort = prop.getProperty("PORT");
			sUrl = prop.getProperty("URL");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
	}
	public GenericWrappers(RemoteWebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test=test;
	}
	
	//This method is used to load all locators from object property file
	public void loadObjects() {
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./src/main/resources/object.properties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	//This method is used to unload all locators after completing the test execution
	public void unloadObjects() {
		prop = null;
	}
	
	//This method is used to load all data's from data property file
	public void loadDatas() {
		propDatas = new Properties();
		try {
			propDatas.load(new FileInputStream(new File("./src/main/resources/data.properties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	//This method is used to load all data's from data property file
	public void unloadDatas() {
		propDatas = null;
	}
	
	//This method is used to launch the application
	public void launchApplication(String browsers, String url) {
		try {
			// this is for local run
			{  
				if(browsers.equalsIgnoreCase("chrome")){
					System.setProperty("webdriver.chrome.driver", "driver/chromedriver.exe");
					driver = new ChromeDriver();
				}else if(browsers.equalsIgnoreCase("firefox")){
					System.setProperty("webdriver.gecko.driver", "driver/geckodriver.exe");
					driver = new FirefoxDriver();
				}else if(browsers.equalsIgnoreCase("ie")) {
					System.setProperty("webdriver.ie.driver", "driver/IEDriverServer.exe");
					driver = new InternetExplorerDriver();
				}else{
					
				}
			}
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.get(url);
			primaryWindowHandle = driver.getWindowHandle();
			reportStep("The browser:" + browsers + " launched successfully", "PASS");
			Reporter.log("The browser:" + browsers + " launched successfully", true);
		} catch (Exception e) {
			
		}
	}

	//This method is used to verify the text using xpath as a locator
	public void verifyTextByXpath(String xpath, String text){
		try {
			String sText = driver.findElementByXPath(xpath).getText();
			if (sText.equalsIgnoreCase(text)){
			}else{
				Assert.fail("The text: "+sText+" did not match with the value :"+text);
			}
		}catch (Exception e) {
			Assert.fail("Unknown exception occured while verifying the title");
		}
	}
	
	//This method is used to close all the browser windows which is opened by webdriver
	public void closeAllBrowsers() {
		try {
			driver.quit();
			reportStep("All browsers are closed successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("Unable to close the browser");
		}
	}
	
	//This method is used to close the current active window which is opened by webdriver
	public void closeBrowser() {
		try {
			driver.close();
			reportStep("Browser is closed successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("Unable to close the browser");
		}
	}

	//This method is used to get the element text by using xpath
	public String getTextByXpath(String xpathVal){
		String bReturn = "";
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathVal)));
			return element.getText();
			
		} catch (Exception e) {
			Assert.fail("The element with "+xpathVal+" could not be found.");
		}
		return bReturn; 
	}

	//This method is used to get the element text by using id as a locator
	public String getTextById(String idVal) {
		String bReturn = "";
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.id(idVal)));
			return element.getText();
		} catch (Exception e) {
			Assert.fail("The element with "+idVal+" could not be found.");
		}
		return bReturn; 
	}

	//This method is used to select the text from drop down list using Id as a locator
	public void selectVisibileTextById(String id, String value) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.id(id)));
			new Select(element).selectByVisibleText(value);			
			reportStep("[INFO] element " +id+" "+ "is selected successfully", "PASS");
			Reporter.log("[INFO] element " +id+" "+ "is selected successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] value: "+value+" "+" could not be selected.", "FAIL");
		}
	}
	
	//This method is used to select the text from drop down list using name as a locator
	public void selectVisibileTextByName(String nameValue, String value) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.name(nameValue)));
			new Select(element).selectByVisibleText(value);			
			reportStep("[INFO] element " +nameValue+" "+ "is selected successfully", "PASS");
			Reporter.log("[INFO] element " +nameValue+" "+ "is selected successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] value: "+nameValue+" "+" could not be selected.", "FAIL");
		}
	}
	//This method is used to select the text from drop down list using xpath as a locator
	public void selectByValueXpath(String xpathValue, String value) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathValue)));
			new Select(element).selectByValue(value);
			reportStep("[INFO] element " +xpathValue+" "+ "is selected successfully", "PASS");
			Reporter.log("[INFO] element " +xpathValue+" "+ "is selected successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] value: "+xpathValue+" "+" could not be selected.", "FAIL");
		}
	}
	//This method is used to select the text from drop down list using name as a locator
	public void selectVisibileTextByValue(String nameValue, String value) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.name(nameValue)));
			new Select(element).selectByValue(value);			
			reportStep("[INFO] element " +nameValue+" "+ "is selected successfully", "PASS");
			Reporter.log("[INFO] element " +nameValue+" "+ "is selected successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] value: "+nameValue+" "+" could not be selected.", "FAIL");
		}
	}

	//This method is used to select the text from drop down list using Xpath as a locator
	public void selectVisibileTextByXPath(String xpathValue, String value) {
		try{
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathValue)));
			new Select(element).selectByVisibleText(value);
			reportStep("[INFO] element " +xpathValue+" "+ "is selected successfully", "PASS");
			Reporter.log("[INFO] element " +xpathValue+" "+ "is selected successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] value: "+xpathValue+" "+" could not be selected.", "FAIL");
		}
	}

	//This method is used to select the text from drop down list using index value and locator is Id 
	public void selectIndexById(String id, int value) {
		try{
			new Select(driver.findElement(By.id(id))).selectByIndex(value);
		} catch (Exception e) {
			Assert.fail("The index: "+value+" could not be selected.");
		}
	}

	//This method is used to switch to the parent window 
	public void switchToParentWindow() {
		try {
			Set<String> winHandles = driver.getWindowHandles();
			for (String wHandle : winHandles) {
				driver.switchTo().window(wHandle);
				String Title=driver.switchTo().window(wHandle).getTitle();
				Reporter.log(Title, true);
				break;
			}
		} catch (Exception e) {
			Assert.fail("The window could not be switched to the first window.");
		}
	}
	
	//This method is used to switch to the last window which is opened by webdriver
	public void switchToLastWindow() {
		try {
			/*Set<String> winHandles = driver.getWindowHandles();
			for (String wHandle : winHandles) {
				driver.switchTo().window(wHandle);
			}*/
			
			Set<String> allWindowHandles = driver.getWindowHandles();
			 
			 for(String handle : allWindowHandles)
			 {
			 System.out.println("Window handle - > " + handle);
			 }
			 
		} catch (Exception e) {
			Assert.fail("The window could not be switched to the last window.");
		}
	}

	//This method is used to accept the alert
	public void acceptAlert() {
		try {
			driver.switchTo().alert().accept();
		} catch (NoAlertPresentException e) {
			Assert.fail("The alert could not be found.");
		} catch (Exception e) {
			Assert.fail("The alert could not be accepted.");
		}
	}

	//This method is used to get the text from alert pop up 
	public String getAlertText() {		
		String text = null;
		try {
			Alert alt = driver.switchTo().alert();
			text = alt.getText();
			Reporter.log(text, true);
		} catch (NoAlertPresentException e) {
			Assert.fail("The alert could not be found.");
		} catch (Exception e) {
			Assert.fail("The alert could not be accepted.");
		}
		return text;
	}

	//This method is used to dismiss the alert pop up
	public void dismissAlert() {
		try {
			driver.switchTo().alert().dismiss();
		} catch (NoAlertPresentException e) {
			Assert.fail("The alert could not be found.");
		} catch (Exception e) {
			Assert.fail("The alert could not be accepted.");
		}
	}

	//This method is used to take the screenshot and store it into some place
	public long takeSnap(){
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			FileUtils.copyFile(driver.getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".jpg"));
		} catch (WebDriverException e) {
			reportStep("The browser has been closed.", "FAIL");
		} catch (IOException e) {
			reportStep("The snapshot could not be taken", "WARN");
		}
		return number;
	}

	//This method is used to switch the frame by using string
	public void switchToFrameByString(String frame) {
		try {
			driver.switchTo().frame(frame);
			Reporter.log("[Info] navigated to frame with name ", true);
		} catch (NoSuchFrameException e) {
			Reporter.log("[Info] Unable to locate frame with name " + e.getStackTrace(), true);
		} catch (Exception e) {
			Reporter.log("[Info] Unable to navigate to frame with name "+ e.getStackTrace(), true);
		}
	}
	
	//This method is used to switch the frame using index
	public void switchToFrameByindex(int index){
		try{
			driver.switchTo().frame(index);
			Reporter.log("[Info] Navigated to frame with index ", true);
		} catch (NoSuchFrameException e) {
			Reporter.log("[Info] Unable to locate frame with index " + e.getStackTrace(), true);
		} catch (Exception e) {
			Reporter.log("[Info] Unable to navigate to frame with index "+ e.getStackTrace(), true);
		}
	}
	
	//This method is used to switch back from frame
	public void switchToDefault(){
		try{
			driver.switchTo().defaultContent();
			Reporter.log("[Info] navigated back from frame", true);
		}catch (Exception e) {
			Reporter.log("[Info] Unable to navigate back from frame", true);
		}
	}
	
	//This method is used to scroll down the page using java script executor
	public void scrollDownPage(){
		try{
			JavascriptExecutor jse = (JavascriptExecutor) driver;
		    jse.executeScript("window.scrollBy(0,250)", "");
		}catch (Exception e) {
			Reporter.log("Unable to Scroll the page down", true);
		}
	}

	//This method is used to get the text using contains xpath
	public void getTextContainsByXpath(String xpath, String text) {
		try {
			String sText = driver.findElementByXPath(xpath).getText();
			if (sText.contains(text)) {
			} else {
				Assert.fail("The text: " + sText + " did not match with the value :" + text);
			}
		} catch (Exception e) {
			Assert.fail("Unknown exception occured while verifying the title");
		}
	}
	
	//This method is used to get the text using xpath as a locator
	public void setExplicitWaitGetByXpath(String xpathVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathVal)));
			element.getText();
			reportStep("[INFO] element " +xpathVal+" "+ "is identified successfully", "PASS");
			Reporter.log("[INFO] element " +xpathVal+" "+ "is identified successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with xpath: " + xpathVal + " could not be identified.","FAIL");
		}
	}
	
	//This method is used to get the text by using id as a locator
	public void setExplicitWaitGetById(String id) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.id(id)));
			element.getText();
			reportStep("[INFO] element " +id+" "+ "is identified successfully", "PASS");
			Reporter.log("[INFO] element " +id+" "+ "is identified successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with xpath: " + id + " could not be identified.","FAIL");
		}
	}
	
	//This method is used to click the button using xpath as a locator
	public void setExplicitWaitClickByXpath(String xpathVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.xpath(xpathVal)));
			element.click();
			reportStep("[INFO] element " + xpathVal +" "+ "is clicked successfully", "PASS");
			Reporter.log("[INFO] element " + xpathVal +" "+ "is clicked successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with xpath: " + xpathVal + " could not be clicked.", "FAIL");
		}
	}
	
	//This method is used to click the button using css selector as a locator
	public void setExplicitWaitClickByCssSelector(String cssValue) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.cssSelector(cssValue)));
			element.click();
			reportStep("[INFO] element "+cssValue+" "+ "is clicked", "PASS");
			Reporter.log("[INFO] element "+cssValue+" "+ "is clicked", true);
		} catch (Exception e) {
			reportStep("[INFO] element with xpath: " + cssValue + " could not be clicked.", "FAIL");
		}
	}	
	
	//This method is used to get the element text using class name
	public void setExplicitWaitByClassName(String className) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.className(className)));
			element.getText();
			Reporter.log("[INFO] element" +className+" "+ "is identified successfully", true);
			reportStep("[INFO] element" +className+" "+ "is identified successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("The element with className: " + className + " could not be identified.");
			reportStep("The element with className: " + className + " could not be identified.", "FAIL");
		}
	}	
	
	//This method is used to enter the text in text box using xpath
	public void setExplicitWaitEnterByXpath(String xpathVal, String value) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathVal)));
			element.clear();
			element.sendKeys(value);
			reportStep("[INFO] element " + xpathVal +" "+ "value entered successfully", "PASS");
			Reporter.log("[INFO] element " + xpathVal +" "+ "value entered successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with xpath: " + xpathVal +" "+ " could not be identified.", "FAIL");
		}
	}
	
	//This method is used to click the link/linktext using linktext as a locator
	public void setExplicitWaitClickByLink(String linkText) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.linkText(linkText)));
			element.click();
			reportStep("[INFO] element " + linkText +" "+ "is clicked successfully", "PASS");
			Reporter.log("[INFO] element " + linkText +" "+ "is clicked successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with linktext: " + linkText + " could not be clicked.", "FAIL");
		}
	}
	
	//This method is used to click the button using Id as a locator
	public void setExplicitWaitClickById(String idVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.id(idVal)));
			element.click();
			Reporter.log("[INFO] element " + idVal +" "+ "is clicked successfully", true);
			reportStep("[INFO] element " + idVal +" "+ "is clicked successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("The element " + idVal + " could not be clicked.");
			reportStep("The element " + idVal + " could not be clicked.","FAIL");
		}		
	}
	
	//This method is used to click the button using Class Name as a locator
	public void setExplicitWaitClickByClassName(String classNameVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.className(classNameVal)));
			element.click();
			Reporter.log("[INFO] element " + classNameVal +" "+ "is clicked successfully", true);
			reportStep("[INFO] element " + classNameVal +" "+ "is clicked successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("The element with " + classNameVal + " could not be clicked.");
			reportStep("The element with " + classNameVal + " could not be clicked.","FAIL");
		}		
	}
	
	//This method is used to click the button using Name as a locator
	public void setExplicitWaitClickByName(String nameVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.elementToBeClickable(By.name(nameVal)));
			element.click();
			Reporter.log("[INFO] element " + nameVal +" "+ "is clicked successfully", true);
			reportStep("[INFO] element " + nameVal +" "+ "is clicked successfully", "PASS");
		} catch (Exception e) {
			Assert.fail("The element with " + nameVal + " could not be clicked.");
			reportStep("The element with " + nameVal + " could not be clicked.","FAIL");
		}		
	}
	
	//This method is used to get the element text using name as a locator
	public void setExplicitWaitByName(String nameVal) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.name(nameVal)));
			element.getText();
		} catch (Exception e) {
			Assert.fail("The element with name: " + nameVal + " could not be identified.");
		}		
	}	
	
	//This method is used to enter the text in text box using Name as a locator
	public void setExplicitWaitEnterByName(String nameValue, String data) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.name(nameValue)));
			driver.findElement(By.name(nameValue)).clear();
			element.sendKeys(data);
			Reporter.log("[INFO] element " + nameValue +" "+ "value is entered successfully", true);
			reportStep("[INFO] element " + nameValue +" "+ "value is entered successfully", "PASS");
		} catch (Exception e) {
			reportStep("The element with name: " + nameValue + " could not be identified.", "FAIL");
			Reporter.log("The element with name: " + nameValue + " could not be identified.", true);
		}		
	}	
	
	//This method is used to enter the text in text box using Class Name as a locator
	public void setExplicitWaitEnterByClassName(String nameValue, String data) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.name(nameValue)));
			driver.findElement(By.className(nameValue)).clear();
			element.sendKeys(data);
			Reporter.log("[INFO] element " + nameValue +" "+ "value is entered successfully", true);
			reportStep("[INFO] element " + nameValue +" "+ "value is entered successfully", "PASS");
		} catch (Exception e) {
			reportStep("The element with name: " + nameValue + " could not be identified.", "FAIL");
			Reporter.log("The element with name: " + nameValue + " could not be identified.", true);
		}		
	}	
	
	//This method is used to enter the text in text box using Id as a locator
	public void setExplicitWaitEnterById(String idVal, String value) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
			WebElement element = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(By.id(idVal)));
			driver.findElement(By.id(idVal)).clear();
			element.sendKeys(value);
			reportStep("[INFO] element " + idVal +" "+ "value entered successfully", "PASS");
			Reporter.log("[INFO] element " + idVal +" "+ "value entered successfully", true);
		} catch (Exception e) {
			reportStep("[INFO] element with id: " + idVal +" "+ " could not be identified.", "FAIL");
		}		
	}	

	//This method is used to scroll down the page using javascript executor
    public void pageScroll(String scroll, String val){
    	try{
    		JavascriptExecutor jse = (JavascriptExecutor)driver;
    		jse.executeScript(scroll, val);
    	}catch(Exception e){
    		 
    	}
     }
    
    //This method is used to wait till element loading using id as a locator
    public void setExplicitWaitById(String idVal) {
        try {
             WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
             wait.until(
                       ExpectedConditions.presenceOfElementLocated(By.id(idVal)));
             Reporter.log("[INFO] element " +idVal+" "+ "is identified successfully", true);
             reportStep("[INFO] element " +idVal+" "+ "is identified successfully", "Pass");
         } catch (Exception e) {
        	 reportStep("The element with idVal: "+idVal+" "+ "could not be identified.", "FAIL");
        	 Reporter.log("The element with idVal: "+idVal+" "+ "could not be identified.", true);
         }
     } 
     
    //This method is used to wait till element loading using xpath as a locator
    public void setExplicitWaitByXpath(String xpathVal) {
        try {
             WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
             wait.until(
                       ExpectedConditions.visibilityOfElementLocated(By.id(xpathVal)));
             Reporter.log("[INFO] element " +xpathVal+" "+ "is identified successfully", true);
             reportStep("[INFO] element " +xpathVal+" "+ "is identified successfully", "Pass");
         } catch (Exception e) {
        	 reportStep("The element with idVal: "+xpathVal+" "+ "could not be identified.", "FAIL");
        	 Reporter.log("The element with idVal: "+xpathVal+" "+ "could not be identified.", true);
         }
     }
     //This method is used to wait till element loading using css selector as a locator
     public void setExplicitWaitByCssSelector(String cssVal) throws StaleElementReferenceException{
         try {
              WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME);
              wait.until(
                      ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssVal)));
              reportStep("[INFO] element " +cssVal+" "+ "is identified successfully", "PASS");
              Reporter.log("[INFO] element " +cssVal+" "+ "is identified successfully", true);
         } catch (StaleElementReferenceException e) {
        	 reportStep("[INFO] element with cssVal: " + cssVal + " could not be identified.", "FAIL");
         }
     }  
    
    //This method is used to get the site url depends upon command given in command prompt 
 	public String getSiteUrl(String siteName){
	    String siteUrl = System.getProperties().getProperty("login");	    
	    return (null == siteUrl || siteUrl.isEmpty()) ? propDatas.getProperty(siteName+"url") : siteUrl;
 	}   
 	
 	//This method is used to verify the text by using xpath as a locator
	public void getVerifyTextByXpath(String xpath, String text){
		try {
			String sText = driver.findElementByXPath(xpath).getText();
			Assert.assertEquals(sText, text);
			Reporter.log("[INFO] element " +xpath+" "+ "is verified successfully", true);
			reportStep("[INFO] element " +xpath+" "+ "is verified successfully", "PASS");
		}catch (Exception e) {
			Reporter.log("[INFO] element " +xpath+" "+ "is not verified successfully", true);
			reportStep("[INFO] element " +xpath+" "+ "is not verified", "FAIL");

		}
	}    
	
	//This method is used to verify the assertion of the actual and expected behaviors
	public void assertVerification(String actual, String expected){
		try{
			Assert.assertEquals(actual, expected);
			Reporter.log("[INFO] assert verification success", true);
			reportStep("[INFO] assert verification success", "PASS");
		}catch (Exception e) {
			Reporter.log("[INFO] assert verification Failed", true);
			reportStep("[INFO] assert verification Failed", "FAIL");
		}
	}
	
	//This method is used to verify the assertion of the actual and expected behaviors
	public void assertVerify(String actual, String expected){
		try{
			Assert.assertTrue(actual.contains(expected));
			Reporter.log("[INFO] assert verification success", true);
			reportStep("[INFO] assert verification success", "PASS");
		}catch (Exception e) {
			Reporter.log("[INFO] assert verification Failed", true);
			reportStep("[INFO] assert verification Failed", "FAIL");
		}
	}
	
	//This method is used to close the Print Window
	public void printWindow(){
		try{
			driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
			WebElement webElement = driver.findElement(By.tagName("body"));
			webElement.sendKeys(Keys.TAB);
			webElement.sendKeys(Keys.ENTER);
			driver.switchTo().window(driver.getWindowHandles().toArray()[0].toString());
		}catch (Exception e) {
			Reporter.log("[INFO] Print Window not Closed", true);
			reportStep("[INFO] Print Window not Closed", "FAIL");
		}
	}
}