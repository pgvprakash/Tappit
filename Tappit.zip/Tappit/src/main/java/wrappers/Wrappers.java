package wrappers;


public interface Wrappers {
	
	//This method is used to load all locators from object property file
	public void loadObjects();
	
	//This method is used to unload all locators after completing the test execution
	public void unloadObjects();
	
	//This method is used to load all data's from data property file
	public void loadDatas();
	
	//This method is used to unload all data's after completing the test execution
	public void unloadDatas();
	
	//This method is used to launch the application
	public void launchApplication(String browsers, String url);
	
	//This method is used to verify the text using xpath
	public void verifyTextByXpath(String xpath, String text);
	
	//This method is used to close all the browsers launched by webdriver
	public void closeAllBrowsers();
	
	//This method is used to close only current active window
	public void closeBrowser();
	
	//This method is used to get the text using xpath as a locator
	public String getTextByXpath(String xpathVal);
	
	//This method is used to get the text using id as a locator
	public String getTextById(String idVal);
	
	//This method is used to select the text from drop down list using id
	public void selectVisibileTextById(String id, String value);
	
	//This method is used to select the text from drop down list using xpath
	public void selectVisibileTextByXPath(String xpath, String value);
	
	//This method is used to select the index from drop down list using id
	public void selectIndexById(String id, int value);
	
	//This method is used to get the parent window id/name
	public void switchToParentWindow();
	
	//This method is used to get the last window id/name
	public void switchToLastWindow();
	
	//This method is used to accept the alert
	public void acceptAlert();
	
	//This method is used to get the text in alert message
	public String getAlertText();
	
	//This method is used to dismiss the alert
	public void dismissAlert();
	
	//This method is used to take the snapshot/screenshot
	public long takeSnap();
	
	//This method is used to switch the frame
	public void switchToFrameByString(String frame);
	
	//This method is used to scroll down the page
	public void scrollDownPage();
	
	//This method is used to get the text using contains xpath
	public void getTextContainsByXpath(String xpath, String text);
	
	//This method is used to get the text using xpath
	public void setExplicitWaitGetByXpath(String xpathVal);
	
	//This method is used to get the text using id
	public void setExplicitWaitGetById(String id);
	
	//This method is used to click the button using xpath
	public void setExplicitWaitClickByXpath(String xpathVal);
	
	//This method is used to click the button using css selector
	public void setExplicitWaitClickByCssSelector(String cssValue);
	
	//This method is used to get the text using class name
	public void setExplicitWaitByClassName(String className);
	
	//This method is used to enter the text using xpath
	public void setExplicitWaitEnterByXpath(String xpathVal, String value);
	
	//This method is used to click the links using link text
	public void setExplicitWaitClickByLink(String linkText);
	
	//This method is used to click the button using id
	public void setExplicitWaitClickById(String idVal);
	
	//This method is used to get the text using name
	public void setExplicitWaitByName(String nameVal);
	
	//This method is used to enter the text using name
	public void setExplicitWaitEnterByName(String nameValue, String data);
	
	//This method is used to enter the text using id
	public void setExplicitWaitEnterById(String idVal, String value);
	
	//This method is used to scroll the page
	public void pageScroll(String scroll, String val);
	
	//This method is used to wait the webdriver for certain time to load the object
	public void setExplicitWaitById(String idVal);
	
	//This method is used to wait the webdriver for certain time to load the object
	public void setExplicitWaitByCssSelector(String cssVal);
	
	//This method is used to get the site url depends on command prompt 
	public String getSiteUrl(String siteName);
	
	//This methods is used to verify the text using xpath
	public void getVerifyTextByXpath(String xpath, String text);
}
