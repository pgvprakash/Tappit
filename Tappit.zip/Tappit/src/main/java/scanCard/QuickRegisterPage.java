package scanCard;

import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class QuickRegisterPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public QuickRegisterPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public QuickRegisterPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public QuickRegisterPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public QuickRegisterPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame 
	public QuickRegisterPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public QuickRegisterPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Customer menu link
	public QuickRegisterPage clickCustomer(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.Customer.LinkText"));
		return this;
	}
		
	//This method is used to select the outlet name from the list
	public QuickRegisterPage selectOutlet(){
		selectVisibileTextByName(prop.getProperty("Card.Outlet.Name"), propDatas.getProperty("outlet.Create.OutletName"));
		return this;
	}
	
	//This method is used to select the terminal name from the list
	public QuickRegisterPage selectTerminal(){
		selectVisibileTextByName(prop.getProperty("Card.Terminal.Name"), propDatas.getProperty("Terminal.Create.TerminalId"));
		return this;
	}
	
	//This method is used to click the Save button in outlet selection page
	public QuickRegisterPage clickSave(){
		setExplicitWaitClickByXpath(prop.getProperty("Card.Save.Xpath"));
		return this;
	}
	
	//This method is used to select the Program from the list
	public QuickRegisterPage selectProgram(){
		selectVisibileTextByName(prop.getProperty("Card.Program.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to enter the CID in given field
	public QuickRegisterPage enterCID(){
		setExplicitWaitEnterByName(prop.getProperty("Card.CID.Name"), propDatas.getProperty("Lot.Upload.Cards"));
		return this;
	}
	
	//This method is used to click the enter button
	public QuickRegisterPage clickEnter(){
		setExplicitWaitClickByXpath(prop.getProperty("Card.Enter.Xpath"));
		return this;
	}
	
	//This method is used to enter the preload amount in given field
	public QuickRegisterPage enterAmount(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.Amount.Xpath"), propDatas.getProperty("Card.Register.Amount"));
		return this;
	}
	
	//This method is used to select the currency from the list
	public QuickRegisterPage selectCurrency(){
		selectVisibileTextByXPath(prop.getProperty("Card.Currency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to select the country from the list
	public QuickRegisterPage selectCountry(){
		selectVisibileTextByXPath(prop.getProperty("Card.Country.Xpath"), propDatas.getProperty("Card.Register.Country"));
		return this;
	}
	
	//This method is used to enter the area code in the given field
	public QuickRegisterPage enterCode(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.Code.Xpath"), propDatas.getProperty("Card.Register.Code"));
		return this;
	}
	
	//This method is used to enter the phone number in the given field
	public QuickRegisterPage enterPhone(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.Phone.Xpath"), propDatas.getProperty("Card.Register.Phone"));
		return this;
	}
	
	//This method is used to click the Submit button
	public QuickRegisterPage clickSubmit()throws Exception {
		setExplicitWaitClickByXpath(prop.getProperty("Card.Submit.Xpath"));
		Thread.sleep(6000);
		return this;
	}
	
	//This method is used to verify the heading in card details page
	public QuickRegisterPage verifyHeading(){
		String actualHeading=getTextByXpath(prop.getProperty("Card.Heading.Xpath"));
		String expectedHeading=propDatas.getProperty("Lot.Upload.Cards");
		assertVerification(actualHeading, expectedHeading);
		return this;
	}
	
	//This method is used to click the load menu
	public QuickRegisterPage clickLoad(){
		setExplicitWaitClickByXpath(prop.getProperty("Card.Load.Xpath"));
		return this;
	}
	
	//This method is used to enter the amount in given field
	public QuickRegisterPage enterLoadAmount(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.LoadAmount.Xpath"), propDatas.getProperty("Card.Register.Amount"));
		return this;
	}
	
	//This method is used to select the load currency from the list
	public QuickRegisterPage selectLoadCurrency(){
		selectVisibileTextByXPath(prop.getProperty("Card.LoadCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to select load source from the list
	public QuickRegisterPage selectLoadSource(){
		selectVisibileTextByXPath(prop.getProperty("Card.LoadSource.Xpath"), propDatas.getProperty("Card.Load.LoadSource"));
		return this;
	}
	
	//This method is used to click the load button
	public QuickRegisterPage clickLoadButton()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Card.LoadButton.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to close the print window by using window handle
	public QuickRegisterPage closePrintWindow()throws Exception{
		printWindow();
		Thread.sleep(10000);
		return this;
	}

	//This method is used to verify the loaded amount in card details page
	public QuickRegisterPage verifyLoadAmount(){
		String actualAmount=getTextByXpath(prop.getProperty("Card.VerifyAmount.Xpath"));
		String expectedAmount=propDatas.getProperty("Card.Register.Amount");
		double val=Double.parseDouble(actualAmount);
	    String[] arr=String.valueOf(val).split("\\.");
	    int[] intArr=new int[2];
	    intArr[0]=Integer.parseInt(arr[0]); 
	    intArr[1]=Integer.parseInt(arr[1]);
	    String str1 = Integer.toString(intArr[0]);
		assertVerification(str1, expectedAmount);
		return this;
	}
	
	//This method is used to click the redeem link in card details page
	public QuickRegisterPage clickRedeem(){
		setExplicitWaitClickByXpath(prop.getProperty("Card.Redeem.Xpath"));
		return this;
	}
	
	//This method is used to enter the amount in given field
	public QuickRegisterPage enterRedeemAmount(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.RedeemAmount.Xpath"), propDatas.getProperty("Card.Redeem.Amount"));
		return this;
	}
	
	//This method is used to select the currency from the list
	public QuickRegisterPage selectRedeemCurrency(){
		selectVisibileTextByXPath(prop.getProperty("Card.RedeemCurrency.Xpath"), propDatas.getProperty("CurrMgnt.Edit.AccountName"));
		return this;
	}
	
	//This method is used to enter the description in the given field
	public QuickRegisterPage enterDescription(){
		setExplicitWaitEnterByXpath(prop.getProperty("Card.RedeemDescription.Xpath"), propDatas.getProperty("Card.Redeem.Description"));
		return this;
	}
	
	//This method is used to select the redeem source from the list
	public QuickRegisterPage selectRedemmSource(){
		selectVisibileTextByXPath(prop.getProperty("Card.RedeemSource.Xpath"), propDatas.getProperty("Card.Load.LoadSource"));
		return this;
	}
	
	//This method is used to click the redeem button 
	public QuickRegisterPage clickRedeemButton()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Card.RedeemButton.Xpath"));
		Thread.sleep(2000);
		return this;
	}
	
	//This method is used to click the Details link in the card details page
	public QuickRegisterPage clickDetails()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Card.Details.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to verify the redeemed amount in card details page
	public QuickRegisterPage verifyRedeem(){
		String actualAmount=getTextByXpath(prop.getProperty("Card.RedeemAmountVerify.Xpath"));
		String expectedAmount=propDatas.getProperty("Card.Redeem.Amount");
		double val=Double.parseDouble(actualAmount);
	    String[] arr=String.valueOf(val).split("\\.");
	    int[] intArr=new int[2];
	    intArr[0]=Integer.parseInt(arr[0]); 
	    intArr[1]=Integer.parseInt(arr[1]);
	    String str1 = Integer.toString(intArr[0]);
		assertVerification(str1, expectedAmount);
		return this;
	}
	
	
}
