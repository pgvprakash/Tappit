package programs;

import java.util.Scanner;

public class RevereString {
	
	public static void main(String[] args){
		
		System.out.println("Enter the required String:");
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		String reverse="";
		
		for(int i=str.length()-1; i>=0; i--){
			
			reverse = reverse + str.charAt(i);
			
		}
		System.out.println("Reversed String is:");
		System.out.println(reverse);
		
	}

}
