package areaManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class EditAreaManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public EditAreaManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditAreaManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditAreaManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditAreaManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public EditAreaManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditAreaManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditAreaManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Area Management sub menu
	public EditAreaManagementPage clickAreaManagement(){
		setExplicitWaitClickById(prop.getProperty("Area.Menu.Id"));
		return this;
	}
	
	//This method is used to enter the outlet/area name search outlet field
	public EditAreaManagementPage searchOutlet(){
		setExplicitWaitEnterByName(prop.getProperty("Area.SearchOutlet.Name"), propDatas.getProperty("area.Create.Name"));
		return this;
	}
	
	//This method is used to click the filter button
	public EditAreaManagementPage clickFilter(){
		setExplicitWaitClickById(prop.getProperty("Area.Filter.Id"));
		return this;
	}
	
	//This method is used to click the Edit icon in required area
	public EditAreaManagementPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Area.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to update the existing outlet name in given field
	public EditAreaManagementPage enterOutlet(){
		setExplicitWaitEnterByXpath(prop.getProperty("Area.EditOutlet.Xpath"), propDatas.getProperty("area.Edit.OutletOwner"));
		return this;
	}
	
	//This method is used to update the existing max count in given field
	public EditAreaManagementPage enterMaxCount(){
		setExplicitWaitEnterByXpath(prop.getProperty("Area.EditMaxCount.Xpath"), propDatas.getProperty("area.Edit.MaxCount"));
		return this;
	}
	
	//This method is used to update the existing alert count in given field
	public EditAreaManagementPage enterAlertCount(){
		setExplicitWaitEnterByXpath(prop.getProperty("Area.EditAlertCount.Xpath"), propDatas.getProperty("area.Edit.AlertCount"));
		return this;
	}
	
	//This method is used to click save changes button
	public EditAreaManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Area.SaveChanges.Xpath"));
		String text=getTextByXpath(prop.getProperty("Area.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		Thread.sleep(2000);
		return this;
	}
}