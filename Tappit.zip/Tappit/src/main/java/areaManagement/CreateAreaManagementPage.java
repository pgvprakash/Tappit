package areaManagement;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateAreaManagementPage extends Tappit {
	
	// This is to confirm you are in Login Page
	public CreateAreaManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateAreaManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateAreaManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateAreaManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateAreaManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateAreaManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateAreaManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Area Management sub menu
	public CreateAreaManagementPage clickAreaManagement(){
		setExplicitWaitClickById(prop.getProperty("Area.Menu.Id"));
		return this;
	}
	
	//This menu is used to click the Add Area link
	public CreateAreaManagementPage clickAddArea(){
		setExplicitWaitClickByLink(prop.getProperty("Area.AddArea.LinkText"));
		return this;
	}
	
	//This method is used to enter the name in the given text field
	public CreateAreaManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Area.Name.Name"), propDatas.getProperty("area.Create.Name"));
		return this;
	}
	
	//This method is used to enter the city in the given text field
	public CreateAreaManagementPage enterCity(){
		setExplicitWaitEnterByName(prop.getProperty("Area.City.Name"), propDatas.getProperty("area.Create.City"));
		return this;
	}
	
	//This method is used to enter the State in the given field
	public CreateAreaManagementPage enterState(){
		setExplicitWaitEnterByName(prop.getProperty("Area.State.Name"), propDatas.getProperty("area.Create.State"));
		return this;
	}
	
	//This method is used to enter the zip code in the given field
	public CreateAreaManagementPage enterZipCode(){
		setExplicitWaitEnterByName(prop.getProperty("Area.ZipCode.Name"), propDatas.getProperty("area.Create.ZipCode"));		
		return this;
	}
	
	//This method is used to select the country from the drop down list
	public CreateAreaManagementPage selectCountry(){
		selectVisibileTextByValue(prop.getProperty("Area.Country.Name"), propDatas.getProperty("area.Create.Country"));
		return this;
	}
	
	//This method is used to enter the outlet owner in given field
	public CreateAreaManagementPage enterOutletOwner(){
		setExplicitWaitEnterByName(prop.getProperty("Area.OutletOwner.Name"), propDatas.getProperty("area.Create.OutletOwner"));
		return this;
	}
	
	//This method is used to select the event from the drop down list
	public CreateAreaManagementPage selectEvent(){
		selectVisibileTextByName(prop.getProperty("Area.Event.Name"), propDatas.getProperty("eventMgnt.Edit.EventName"));
		return this;
	}
	
	//This method is used to enter the Maximum count in the given field
	public CreateAreaManagementPage enterMaxCount(){
		setExplicitWaitEnterByName(prop.getProperty("Area.MaxCount.Name"), propDatas.getProperty("area.Create.MaxCount"));
		return this;
	}
	
	//This method is used to enter the alert count in the given field
	public CreateAreaManagementPage enterAlertCount(){
		setExplicitWaitEnterByName(prop.getProperty("Area.AlertCount.Name"), propDatas.getProperty("area.Create.AlertCount"));
		return this;
	}
	
	//This method is used to select the access area(true/false) from the list
	public CreateAreaManagementPage selectAccessArea(){
		selectVisibileTextByName(prop.getProperty("Area.AccessArea.Name"), propDatas.getProperty("area.Create.AccessArea"));
		return this;
	}
	
	//This method is used to click the access control checkbox
	public CreateAreaManagementPage clickAccessControl(){
		setExplicitWaitClickByName(prop.getProperty("Area.AccessControl.Name"));
		return this;
	}
	
	//This method is used to click the Unlimited checkbox
	public CreateAreaManagementPage clickUnlimited(){
		setExplicitWaitClickByName(prop.getProperty("Area.Unlimited.Name"));
		return this;
	}
	
	//This method is used to select the Max Counter from the list
	public CreateAreaManagementPage selectMaxCounter(){
		selectVisibileTextByName(prop.getProperty("Area.MaxCounter.Name"), propDatas.getProperty("area.Create.MaxCounter"));
		return this;
	}
	
	//This method is used to enter the Max Value in given field
	public CreateAreaManagementPage enterMaxValue(){
		setExplicitWaitEnterByName(prop.getProperty("Area.MaxValue.Name"), propDatas.getProperty("area.Create.MaxValue"));
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateAreaManagementPage clickSubmit() throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Area.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to enter the outlet/area name search outlet field
	public CreateAreaManagementPage searchOutlet(){
		setExplicitWaitEnterByName(prop.getProperty("Area.SearchOutlet.Name"), propDatas.getProperty("area.Create.Name"));
		return this;
	}
	
	//This method is used to click the filter button
	public CreateAreaManagementPage clickFilter(){
		setExplicitWaitClickById(prop.getProperty("Area.Filter.Id"));
		return this;
	}
	
	//This method is used to verify the created area in table
	public CreateAreaManagementPage verifyCreatedArea(){
		String actualProgramName=getTextByXpath(prop.getProperty("Area.getAreaName.Xpath"));
		String expectedProgramName=propDatas.getProperty("area.Create.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}
	
	//This method is used to click the Deactivate link in created area
	public CreateAreaManagementPage clickDeactivate(){
		setExplicitWaitClickByXpath(prop.getProperty("Area.ChangeStatus.Xpath"));
		acceptAlert();
		String text=getTextByXpath(prop.getProperty("common.SuccessAlert.Xpath"));
		Reporter.log(text,true);
		return this;
	}
	
/*	//This method is used to verify the area status active/Deactive
	public CreateAreaManagementPage verifyChagneStatus(){
		String actualProgramName=getTextByXpath(prop.getProperty("Area.ChangeStatus.Xpath"));
		String expectedProgramName=propDatas.getProperty("area.Create.Name");
		assertVerification(actualProgramName, expectedProgramName);
		return this;
	}*/
	
	
	//This method is used to show the table data's like 20/30/40
	public CreateAreaManagementPage show(){
		String actualEndId=getTextByXpath(prop.getProperty("EventMgnt.EndId.Xpath"));
		selectByValueXpath(prop.getProperty("EventMgnt.Show.Xpath"), propDatas.getProperty("pgmMgnt.Show.Value"));
		String expectedEndId=getTextByXpath(prop.getProperty("EventMgnt.ShowEndId.Xpath"));
		Assert.assertNotEquals(actualEndId, expectedEndId);
		return this;
	}
	
	//This method is used to verify the next link in bottom of the page
	public CreateAreaManagementPage next(){
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.Next.Xpath"));
		return this;
	}
	
	//This method is used to verify the Previous link in bottom of the page
	public CreateAreaManagementPage previous(){
		setExplicitWaitClickByXpath(prop.getProperty("EventMgnt.Previous.Xpath"));
		return this;
	}
}
