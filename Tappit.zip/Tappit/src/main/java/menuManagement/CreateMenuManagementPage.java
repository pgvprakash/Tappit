package menuManagement;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class CreateMenuManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public CreateMenuManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public CreateMenuManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public CreateMenuManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public CreateMenuManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public CreateMenuManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public CreateMenuManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public CreateMenuManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Menu Management sub menu
	public CreateMenuManagementPage clickMenuManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.MenuLink.Id"));
		return this;
	}
	
	//This method is used to click the Add Menu link
	public CreateMenuManagementPage clickAddMenu(){
		setExplicitWaitClickByLink(prop.getProperty("Menu.AddMenu.LinkText"));
		return this;
	}
	
	//This method is used to enter the Menu Name in the given field
	public CreateMenuManagementPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Menu.MenuName.Name"), propDatas.getProperty("MenuMgnt.Create.MenuName"));
		return this;
	}
	
	//This method is used select the program from the list
	public CreateMenuManagementPage selectProgram(){
		selectVisibileTextByName(prop.getProperty("Menu.Program.Name"), propDatas.getProperty("pgmMgnt.Edit.Name"));
		return this;
	}
	
	//This method is used to select the multi currency from the list
	public CreateMenuManagementPage selectCurrency()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Menu.MultiCurrencyList.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	//This method is used to enter the item groups in given field
	public CreateMenuManagementPage enterItemGroups()throws Exception{
		Actions action = new Actions(driver);
		action.sendKeys(Keys.TAB).build().perform();
		action.sendKeys("alcoholic").build().perform();		
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to select the display group from the list
	public CreateMenuManagementPage selectDisplayGroup(){
		selectVisibileTextByName(prop.getProperty("Menu.DisplayGroups.Name"), propDatas.getProperty("MenuMgnt.Create.DisplayGroups"));
		return this;
	}
	
	//This method is used to choose the display groups from the list
	public CreateMenuManagementPage chooseDisplayGroups()throws Exception{
		Actions action = new Actions(driver);
		action.sendKeys(Keys.TAB).build().perform();
		action.sendKeys("alcoholic").build().perform();
		action.sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the Submit button
	public CreateMenuManagementPage clickSubmit()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Menu.Submit.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the edit items icon
	public CreateMenuManagementPage verifyMenu(){
		String actualMenuName=getTextByXpath(prop.getProperty("Menu.VerifyMenu.Xpath"));
		String expectedMenuName=propDatas.getProperty("MenuMgnt.Create.MenuName");
		assertVerification(actualMenuName, expectedMenuName);
		return this;
	}
}
