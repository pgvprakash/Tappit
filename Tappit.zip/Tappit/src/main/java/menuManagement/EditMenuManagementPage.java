package menuManagement;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.relevantcodes.extentreports.ExtentTest;
import wrappers.Tappit;

public class EditMenuManagementPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditMenuManagementPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditMenuManagementPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditMenuManagementPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditMenuManagementPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public EditMenuManagementPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditMenuManagementPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditMenuManagementPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Menu Management sub menu
	public EditMenuManagementPage clickMenuManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.MenuLink.Id"));
		return this;
	}
	
	//This method is used to click the Edit Icon from the table
	public EditMenuManagementPage clickEditIcon()throws Exception{
		Thread.sleep(3000);
		setExplicitWaitClickByXpath(prop.getProperty("Menu.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to select the default language from the list
	public EditMenuManagementPage clickDefaultLanguage(){
		setExplicitWaitClickByXpath(prop.getProperty("Menu.Language.Xpath"));
		return this;
	}
	
	//This method is used to enter the default language in search field
	public EditMenuManagementPage enterLanguageName(){
		setExplicitWaitEnterByXpath(prop.getProperty("Menu.EnterLanguage.Xpath"), propDatas.getProperty("MenuMgnt.Edit.Language"));
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER).build().perform();
		return this;
	}
	
	//This method is used to click the Save Changes button
	public EditMenuManagementPage clickSaveChanges()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Menu.saveChanges.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the edit items icon
	public EditMenuManagementPage verifyLanguage(){
		String actualLanguageName=getTextByXpath(prop.getProperty("Menu.verifyLanguage.Xpath"));
		String expectedLanguageName=propDatas.getProperty("MenuMgnt.Verify.Language");
		assertVerification(actualLanguageName, expectedLanguageName);
		return this;
	}
}
