package menuManagement;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.Tappit;

public class EditItemsPage extends Tappit{
	
	// This is to confirm you are in Login Page
	public EditItemsPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		launchApplication(browserName,url);
	}
	
	//This method is used to accept the cookies button
	public EditItemsPage acceptCookies(){
		setExplicitWaitClickById(prop.getProperty("Login.AcceptCookie.Id"));
		return this;
	}

	//This method is used to enter the username in given text field
	public EditItemsPage enterUserName(){
		setExplicitWaitEnterById(prop.getProperty("Login.UserName.Id"), propDatas.getProperty("UserName"));
		return this;
	}

	//This method is used to enter the Password in given text field
	public EditItemsPage enterPassword(){
		setExplicitWaitEnterById(prop.getProperty("Login.Password.Id"), propDatas.getProperty("Password"));
		return this;
	}
	
	//This method is used to click the captcha check box inside the frame
	public EditItemsPage selectCaptcha()throws Exception{
		switchToFrameByindex(0);
		setExplicitWaitClickById(prop.getProperty("Login.Captcha.Id"));
		Thread.sleep(3000);
		switchToDefault();
		return this;
	}
	
	//This method is used to click the Submit button in login page
	public EditItemsPage clickLoginButton(){
		setExplicitWaitClickById(prop.getProperty("Login.Button.Id"));
		return this;
	}
	
	//This method is used to click the Event menu link
	public EditItemsPage clickEvent(){
		setExplicitWaitClickByLink(prop.getProperty("EventMgnt.Event.LinkText"));
		return this;
	}
	
	//This method is used to click the Menu Management sub menu
	public EditItemsPage clickMenuManagement(){
		setExplicitWaitClickById(prop.getProperty("Menu.MenuLink.Id"));
		return this;
	}
	
	//This method is used to click the Edit Items icon
	public EditItemsPage clickEditItems(){
		setExplicitWaitClickByXpath(prop.getProperty("Menu.EditItems.Xpath"));
		return this;
	}
	
	//This method is used to click the Edit icon in item listing page
	public EditItemsPage clickEditIcon(){
		setExplicitWaitClickByXpath(prop.getProperty("Menu.EditIcon.Xpath"));
		return this;
	}
	
	//This method is used to select the Category from the list
	public EditItemsPage selectCategory()throws Exception{
		selectVisibileTextByName(prop.getProperty("Menu.Category.Name"), propDatas.getProperty("MenuMgnt.Edit.Category"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to enter the name in the given field
	public EditItemsPage enterName(){
		setExplicitWaitEnterByName(prop.getProperty("Menu.ItemName.Name"), propDatas.getProperty("MenuMgnt.Edit.ItemName"));
		return this;
	}
	
	//This Method is used to enter the rate in the given field
	public EditItemsPage enterRate(){
		setExplicitWaitEnterByXpath(prop.getProperty("Menu.ItemRate.Xpath"), propDatas.getProperty("MenuMgnt.Edit.ItemRate"));
		return this;
	}
	
	//This method is used to select the groups from the list
	public EditItemsPage selectGroup(){
		selectVisibileTextByName(prop.getProperty("Menu.Groups.Name"), propDatas.getProperty("MenuMgnt.Edit.Groups"));
		return this;
	}
	
	//This method is used to click the Update button
	public EditItemsPage clickUpdate()throws Exception{
		setExplicitWaitClickById(prop.getProperty("Menu.Update.Id"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to click the Add Icon from the item listing page
	public EditItemsPage clickAddIcon()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Menu.AddIcon.Xpath"));
		Thread.sleep(3000);
		return this;
	}
	
	//This method is used to enter the name in the given field
	public EditItemsPage enterItemName(){
		setExplicitWaitEnterByName(prop.getProperty("Menu.ItemName.Name"), propDatas.getProperty("MenuMgnt.Add.ItemName"));
		return this;
	}
	
	//This method is used to click the Save Menu button
	public EditItemsPage clickSaveMenu()throws Exception{
		setExplicitWaitClickByXpath(prop.getProperty("Menu.SaveMenu.Xpath"));
		Thread.sleep(6000);
		return this;
	}
}
