package areaManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class EditAreaManagementTest extends Tappit {
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Edit_Area_Mgnt_Test"+"_"+site;
		testDescription = "Area Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testEditAreaManagement() throws Exception{
		new EditAreaManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickEvent()
		.clickAreaManagement()
		.searchOutlet()
		.clickFilter()
		.clickEditIcon()
		.enterOutlet()
		.enterMaxCount()
		.enterAlertCount()
		.clickSaveChanges();
	}
}
