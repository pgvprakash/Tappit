package eventManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import wrappers.Tappit;

public class CreateSessionManagementTest extends Tappit {
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Create_Session_Mgnt_Test"+"_"+site;
		testDescription = "Session Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateSessionManagement() throws Exception{
		new CreateSessionManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickEvent()
		.clickEventManagement()
		.clickSessionIcon()
		.clickAddSession()
		.enterStartTime()
		.enterEndTime()
		.enterSessionName()
		.selectReset()
		.selectLoadCredit()
		.selectResetAccess()
		.clickSubmit()
		.verifyCreatedEvent();
	}
}
