package lotManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import wrappers.Tappit;

public class EditLotManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Edit_Lot_Mgnt_Test"+"_"+site;
		testDescription = "Lot Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testEditLotManagement() throws Exception{
		new EditLotManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickInventory()
		.clickLotManagement()
		.selectProgram()
		.clickEditIcon()
		.editName()
		.editTotalCards()
		.editMinSpendLimit()
		.clickSaveChanges()
		.selectProgram()
		.verifyUpdatedLot();
	}	
}
