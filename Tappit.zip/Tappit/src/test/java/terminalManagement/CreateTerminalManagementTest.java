package terminalManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class CreateTerminalManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Create_Terminal_Mgnt_Test"+"_"+site;
		testDescription = "Terminal Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateTerminalManagement() throws Exception{
		new CreateTerminalManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickInventory()
		.clickTerminal()
		.clickTerminalManagement()
		.clickAddTerminal()
		.enterTerminalId()
		.enterTerminalOwner()
		.enterTerminalName()
		.selectTerminalType()
		.selectOutlet()
		.clickSubmit()
		.searchTerminalName()
		.clickFilter()
		.verifyTerminal();
	}
}
