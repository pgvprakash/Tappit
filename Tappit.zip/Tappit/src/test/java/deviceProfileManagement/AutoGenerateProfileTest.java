package deviceProfileManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class AutoGenerateProfileTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Auto_Generate_Profile_Mgnt_Test"+"_"+site;
		testDescription = "Auto Generate Profile Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateAutoGenerateProfileManagement() throws Exception{
		new AutoGenerateProfilePage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickEvent()
		.clickDeviceProfileManagement()
		.clickAutoGenerateProfile()
		.ClickGenerateButton()
		.ClickSaveChanges();
	}
}
