package deviceProfileManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class CreateDeviceProfileManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Create_Device_Profile_Mgnt_Test"+"_"+site;
		testDescription = "Device Profile Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateDeviceProfileManagement() throws Exception{
		new CreateDeviceProfileManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickEvent()
		.clickDeviceProfileManagement()
		.clickAddDeviceProfile()
		.enterName()
		.selectEvent()
		.clickPOS()
		.clickLoad()
		.clickAccess()
		.selectInvoice()
		.selectAdminDevice()
		.selectQRLoad()
		.selectGPS()
		.selectResetAgentCash()
		.selectDrawer()
		.selectDeviceType()
		.selectFees()
		.selectLogUploadEOD()
		.enterManagerPin()
		.enterAdminPin()
		.selectDoubleTap()
		.selectReconcileDrawer()
		.selectPOSAutoInvoice()
		.selectOnlinePreload()
		.selectSessionInitialization()
		.enterReconcilePin()
		.enterSaleAmountLimit()
		.selectLanguage()
		.enterUrl()
		.enterAppLockPin()
		.selectMode()
		.enterSaleTimeLimit()
		.selectBalance()
		.enterPOSTipsDenom()
		.selectMenu()
		.enterRefundInterval()
		.selectCashout()
		.enterDenom3()
		.enterDenom2()
		.enterDenom1()
		.enableTicketRegister()
		.enterDenom4()
		.enableMultiRegister()
		.selectSourceMode()
		.selectLoadCurrency()
		.selectUnloadCurrency()
		.enableGuestRegister()
		.enableAllowUnknownTicket()
		.selectRegisterMode()
		.enableCustomerRegister()
		.selectGate()
		.enterDisabledArea()
		.enterAccessProfile()
		.enablePrevLocation()
		.enterTimeInterval()
		.enablePrevLocationPrompt()
		.clickSubmit();
	}
}
