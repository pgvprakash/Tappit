package programManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class CreateMemoryManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Create_Memory_Mgnt_Test"+"_"+site;
		testDescription = "Memory Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateMemoryManagement() throws Exception{
		new CreateMemoryManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickInventory()
		.clickProgramManagement()
		.clickAddIcon()
		.enterStartingMemory()
		.clickPOSApp()
		.clickLoadApp()
		.clickAccessApp()
		.clickQRLoad()
		.clickDeposit()
		.clickUnloadDeposit()
		.clickAccess()
		.clickAccessTimer()
		.clickTerminalId()
		.clickGenerate()
		.verifySuccess();
	}
}
