package programManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import programManagement.CreateProgramManagementPage;
import wrappers.Tappit;

public class CreateProgramManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Create_Program_Mgnt_Test"+"_"+site;
		testDescription = "Program Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testCreateProgramManagement() throws Exception{
		new CreateProgramManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickInventory()
		.clickProgramManagement()
		.clickAddProgram()
		.enterName()
		.enterPin()
		.selectMode()
		.selectEvent()
		.selectBasaeCurrency()
		.selectCurrencyType()
		.enterSpendOrder()
		.clickCashout()
		.clickMinSpend()
		.clickPreload()
		.selectCardType()
		.selectVerificationField()
		.selectProgramStatus()
		.selectPreLoad()
		.selectKYC()
		.enterKycAmount()
		.clickAddKycAmountButton()
		.clickSubmitButton()
		.verifyCreatedProgram();
	}
}