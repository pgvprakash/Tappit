package accessFlagManagement;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import wrappers.Tappit;

public class EditAccessFlagManagementTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Edit_Access_Flag_Mgnt_Test"+"_"+site;
		testDescription = "Access Flag Management Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testEditAccessFlagManagement() throws Exception{
		new EditAccessFlagManagementPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickEvent()
		.clickAccessFlagManagement()
		.clickEditIcon()
		.editAccessFlagName()
		.clickSaveChanges()
		.clickSelectName()
		.enterFlagName()
		.clickFlagName()
		.clickFilter()
		.verifyAccessFlagName();
	}
}
