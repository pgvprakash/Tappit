package scanCard;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import wrappers.Tappit;

public class QuickRegisterTest extends Tappit{
	
	@BeforeClass
	@Parameters({"browser", "siteurl", "site"})
	public void setData(@Optional("")String browser, @Optional("")String siteurl, @Optional("")String site) {
		testCaseName = "Quick_Register_Test"+"_"+site;
		testDescription = "Scan Card Page";
		browserName = browser.isEmpty() ? "chrome" : browser;
		url = siteurl.isEmpty() ? getSiteUrl(site) : siteurl;
	    category = "Regression";
		authors = "";
	}
	
	@Test()
	public void testQuickRegister() throws Exception{
		new QuickRegisterPage(driver, test)
		.acceptCookies()
		.enterUserName()
		.enterPassword()
		.selectCaptcha()
		.clickLoginButton()
		.clickCustomer()
		.selectOutlet()
		.selectTerminal()
		.clickSave()
		.selectProgram()
		.enterCID()
		.clickEnter()
		.selectCurrency()
		.selectCountry()
		.enterCode()
		.enterPhone()
		.clickSubmit()
		.verifyHeading()
		.clickLoad()
		.enterLoadAmount()
		.selectLoadCurrency()
		.selectLoadSource()
		.clickLoadButton()
		.closePrintWindow()
		.verifyLoadAmount()
		.clickRedeem()
		.enterRedeemAmount()
		.selectRedeemCurrency()
		.enterDescription()
		.selectRedemmSource()
		.clickRedeemButton()
		.clickDetails()
		.verifyRedeem();
	}
}
